"""
run_ea.py
─────────
Expert Advisor main loop.
Connects to MT5 demo, loads trained models, and executes
the signal pipeline on every new M1 bar.

Usage:
    cd strategy
    python run_ea.py
"""

import sys, os, time, datetime
import MetaTrader5 as mt5
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from strategy import config
from strategy.execution.order_manager import (
    init_mt5, shutdown_mt5, place_order,
    get_account_balance, get_open_positions,
)
from strategy.pipeline.signal_pipeline import SignalPipeline
from strategy.risk.risk_monitor import RiskMonitor


LOOKBACK_BARS = 500     # Increased to 500 for long-window features


def fetch_latest_bars(symbol: str, n: int) -> pd.DataFrame:
    """Fetch the last n bars from MT5 using configured timeframe."""
    tf_map = {
        "M1": mt5.TIMEFRAME_M1,
        "M5": mt5.TIMEFRAME_M5,
        "H1": mt5.TIMEFRAME_H1,
    }
    tf = tf_map.get(config.MT5_TIMEFRAME_NAME, mt5.TIMEFRAME_M5)
    
    rates = mt5.copy_rates_from_pos(symbol, tf, 0, n)
    if rates is None or len(rates) == 0:
        return pd.DataFrame()
    df = pd.DataFrame(rates)
    df["time"] = pd.to_datetime(df["time"], unit="s")
    return df


def is_session_allowed() -> bool:
    """Check session filters: skip first 30 min and last 15 min of day."""
    now = datetime.datetime.now(datetime.timezone.utc)
    h, m = now.hour, now.minute
    minutes_since_midnight = h * 60 + m
    # Forex market is 24h, apply filters around midnight rollover
    if minutes_since_midnight < config.SESSION_OPEN_BUFFER_MIN:
        return False
    if minutes_since_midnight > (24 * 60 - config.SESSION_CLOSE_BUFFER_MIN):
        return False
    return True

def should_retrain(pipeline: "SignalPipeline") -> bool:
    """
    ACTION 7 — Re-entraînement périodique.
    Vérifie si le nombre de jours depuis le dernier entraînement
    dépasse RETRAIN_INTERVAL_DAYS (défaut: 14).
    """
    last_train = getattr(pipeline, "last_train_date", None)
    if last_train is None:
        return False   # jamais entraîné en live — ne pas re-entraîner automatiquement
    interval = getattr(config, "RETRAIN_INTERVAL_DAYS", 14)
    elapsed  = (datetime.datetime.now(datetime.timezone.utc) - last_train).days
    return elapsed >= interval


def retrain_pipeline(pipeline: "SignalPipeline", symbol: str) -> None:
    """
    Télécharge les N derniers mois de données et re-entraîne 'pipeline' en place.
    """
    from strategy.models.feature_engineering import build_features, build_target

    months   = getattr(config, "RETRAIN_LOOKBACK_MONTHS", 6)
    n_bars   = months * 20 * 24 * 12    # approx bars M5 (20 jours/mois, 288 barres/jour)
    tf_map   = {"M1": mt5.TIMEFRAME_M1, "M5": mt5.TIMEFRAME_M5, "H1": mt5.TIMEFRAME_H1}
    tf       = tf_map.get(config.MT5_TIMEFRAME_NAME, mt5.TIMEFRAME_M5)
    rates    = mt5.copy_rates_from_pos(symbol, tf, 0, min(n_bars, 100_000))
    if rates is None or len(rates) < 5000:
        print("[EA] Re-entraînement annulé : pas assez de données")
        return

    df = pd.DataFrame(rates)
    df["time"] = pd.to_datetime(df["time"], unit="s")
    print(f"[EA] Re-entraînement sur {len(df)} barres ({months} mois)...")
    pipeline.fit(df, verbose=False)
    pipeline.last_train_date = datetime.datetime.now(datetime.timezone.utc)
    pipeline.save()
    print("[EA] Re-entraînement terminé et modèles sauvegardés.")

    print("=" * 60)
    print("  ML Expert Advisor — Starting")
    print("=" * 60)

    # ── Connect ──
    if not init_mt5():
        print("FATAL: Cannot connect to MT5.")
        sys.exit(1)

    # ── Load models ──
    pipeline = SignalPipeline()
    try:
        pipeline.load()
        print("[EA] Models loaded successfully.")
    except FileNotFoundError:
        print("[EA] No saved models found. Run train_and_backtest.py first.")
        shutdown_mt5()
        sys.exit(1)

    # ── Risk monitor ──
    balance = get_account_balance()
    risk = RiskMonitor(balance)
    risk.load()
    print(f"[EA] Capital: {risk.capital:.2f}  Drawdown: {risk.drawdown():.2%}")

    # ── Main loop ──
    last_bar_time = None
    print(f"[EA] Monitoring {config.MT5_SYMBOL} {config.MT5_TIMEFRAME_NAME} — press Ctrl+C to stop.\n")

    try:
        while True:
            # Sync closed trades PnL
            risk.update_from_mt5()
            
            # Fetch bars
            df = fetch_latest_bars(config.MT5_SYMBOL, LOOKBACK_BARS)
            if df.empty:
                time.sleep(5)
                continue

            current_bar_time = df["time"].iloc[-1]

            # Only act on new bars
            if last_bar_time is not None and current_bar_time <= last_bar_time:
                time.sleep(2)
                continue

            last_bar_time = current_bar_time

            # ── ACTION 7 : Auto re-entraînement périodique ──
            if should_retrain(pipeline):
                print("[EA] Déclenchement du re-entraînement périodique...")
                retrain_pipeline(pipeline, config.MT5_SYMBOL)

            # Session filter
            if not is_session_allowed():
                continue

            # Skip if already have open positions for this symbol
            positions = get_open_positions(config.MT5_SYMBOL)
            if len(positions) > 0:
                continue

            # ── Evaluate signal ──
            signal = pipeline.evaluate(df, risk)

            ts = current_bar_time.strftime("%H:%M:%S")
            if signal["execute"]:
                dir_str = "BUY" if signal["direction"] == 1 else "SELL"
                print(f"[{ts}] *** SIGNAL: {dir_str}  "
                      f"entry={signal['entry']:.5f}  "
                      f"SL={signal['sl']:.5f}  TP={signal['tp']:.5f}")

                # ── Convert position size to lots ──
                sym_info = mt5.symbol_info(config.MT5_SYMBOL)
                if sym_info is None:
                    print(f"  Symbol info unavailable")
                    continue

                point_value = sym_info.trade_contract_size  # e.g. 100000 for EURUSD
                lots = signal["volume"] / (point_value + 1e-12)
                lots = max(sym_info.volume_min,
                           round(lots / sym_info.volume_step) * sym_info.volume_step)

                result = place_order(
                    symbol=config.MT5_SYMBOL,
                    direction=signal["direction"],
                    volume=lots,
                    sl=signal["sl"],
                    tp=signal["tp"],
                    comment="ML_EA",
                )

                if result.get("ok"):
                    print(f"  ✓ Order executed — deal={result['deal']}  "
                          f"price={result['price']:.5f}  lots={result['volume']}")
                    risk.record_open()     # Only increments trade count
                else:
                    print(f"  ✗ Order failed: {result}")
            else:
                # Quiet log every 10 minutes
                if int(current_bar_time.timestamp()) % 600 < 60:
                    print(f"[{ts}] No signal — {signal['reason']}")

            time.sleep(1)

    except KeyboardInterrupt:
        print("\n[EA] Shutting down …")
    finally:
        risk.save()
        shutdown_mt5()
        print("[EA] Stopped.")


if __name__ == "__main__":
    main()
