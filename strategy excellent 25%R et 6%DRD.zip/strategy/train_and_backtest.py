"""
train_and_backtest.py
---------------------
Downloads historical data from MT5, trains all models,
runs a walk-forward backtest, and prints full statistical reports
for both training and test datasets.

Usage:
    cd strategy
    python train_and_backtest.py
"""

import sys, os, datetime
import numpy as np
import pandas as pd
import MetaTrader5 as mt5
from scipy import stats

# Ensure the parent directory is on the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from strategy import config
from strategy.execution.order_manager import init_mt5, shutdown_mt5
from strategy.backtest.tick_backtester import BarBacktester
from strategy.backtest.metrics_calculator import print_metrics
from strategy.pipeline.signal_pipeline import SignalPipeline
from strategy.models.feature_engineering import build_features, build_target, get_prediction_features


def download_data() -> pd.DataFrame:
    """Download symbols from MT5 with robust retries and smaller chunks."""
    import time
    tf_map = {
        "M1": mt5.TIMEFRAME_M1,
        "M5": mt5.TIMEFRAME_M5,
        "M15": mt5.TIMEFRAME_M15,
        "H1": mt5.TIMEFRAME_H1,
    }
    tf = tf_map.get(config.MT5_TIMEFRAME_NAME, mt5.TIMEFRAME_M1)

    # 18 months of M5 ~= 18 * 22 * 16 * 12 ~= 76,000 bars
    # But for backtest 2023-2025, we might need more. 
    # Let's target 18 months as requested in config.
    target_bars = config.BACKTEST_MONTHS * 22 * 16 * 12
    chunk = 5_000
    all_dfs = []
    offset = 0

    print(f"[Data] Downloading {config.MT5_SYMBOL} {config.MT5_TIMEFRAME_NAME}")
    print(f"       Target: {target_bars:,} bars | Chunk: {chunk:,} | Start: {datetime.datetime.now()}")

    while offset < target_bars:
        n = min(chunk, target_bars - offset)
        rates = None
        
        # Retry logic
        for attempt in range(3):
            rates = mt5.copy_rates_from_pos(config.MT5_SYMBOL, tf, offset, n)
            if rates is not None and len(rates) > 0:
                break
            print(f"  [Retry] Attempt {attempt+1}/3 failed at offset {offset:,}. Sleeping 2s...")
            time.sleep(2)
            
        if rates is None or len(rates) == 0:
            print(f"  [Error] Stopping at offset {offset:,} after retries. MT5 error: {mt5.last_error()}")
            break
            
        df_ = pd.DataFrame(rates)
        all_dfs.append(df_)
        
        ts = datetime.datetime.now().strftime("%H:%M:%S")
        print(f"  [{ts}] offset={offset:,}  got {len(rates):,} bars")
        
        offset += len(rates)
        if len(rates) < n:
            print("  [Data] Reached end of history available on server.")
            break

    if not all_dfs:
        print("[Data] ERROR: no data returned.", mt5.last_error())
        return pd.DataFrame()

    df = pd.concat(all_dfs).drop_duplicates('time').sort_values('time')
    df['time'] = pd.to_datetime(df['time'], unit='s')
    print(f"[Data] Success: {len(df):,} bars from {df['time'].min()} to {df['time'].max()}")
    return df


def statistical_report(y, preds, label="Dataset"):
    """Print a rigorous statistical breakdown of regression quality."""
    n = len(y)
    if n < 1:
        print(f"\n[Stats] {label}: No samples.")
        return

    correct_dir = (np.sign(preds) == np.sign(y))
    acc = correct_dir.mean()
    residuals = y - preds
    mae = np.abs(residuals).mean()
    rmse = np.sqrt((residuals ** 2).mean())
    corr, corr_p = stats.pearsonr(preds, y) if n > 2 else (0, 1)
    t_stat, t_p = stats.ttest_1samp(y, 0) if n > 1 else (0, 1)

    # Profit factor on directional signals
    directional_pnl = y * np.sign(preds)
    wins = directional_pnl[directional_pnl > 0]
    losses = directional_pnl[directional_pnl < 0]
    pf = wins.sum() / (abs(losses.sum()) + 1e-12)

    print(f"\n{'='*60}")
    print(f"  Statistical Report - {label}")
    print(f"{'='*60}")
    print(f"  Samples ............... {n:,}")
    print(f"  Directional Accuracy .. {acc:.2%}")
    print(f"  MAE ................... {mae:.6f}")
    print(f"  RMSE .................. {rmse:.6f}")
    print(f"  Pearson r ............. {corr:.4f}  (p={corr_p:.2e})")
    print(f"  Mean actual return .... {y.mean():.6f}")
    print(f"  Std actual return ..... {y.std():.6f}")
    print(f"  t-statistic ........... {t_stat:.4f}")
    print(f"  p-value (return!=0) ... {t_p:.2e}")
    print(f"  Profit Factor ......... {pf:.4f}")
    print(f"{'='*60}\n")


def main():
    # 1. Connect to MT5
    if not init_mt5():
        print("FATAL: Cannot connect to MT5. Make sure the terminal is running.")
        sys.exit(1)

    # 2. Download data
    df = download_data()
    if df.empty:
        shutdown_mt5()
        sys.exit(1)

    # 3. Backtest
    print("\n" + "="*40)
    print("  PHASE 1: BACKTESTING")
    print("="*40)
    bt = BarBacktester(initial_capital=10_000.0)
    results = bt.run(df, verbose=True)

    # 4. Print results
    print_metrics(results["train_metrics"], "TRAINING SET - In-Sample Statistics")
    print_metrics(results["test_metrics"],  "TEST SET - Out-of-Sample Backtest")
    print(f"  Walk-Forward Score: {results['wf_score']:.3f}")
    print(f"  Number of trades:   {results['test_metrics'].get('n_trades', 0)}")

    # Save data for plotting
    pd.Series(results["equity_curve"]).to_csv("equity_curve.csv", index=False)
    print("\n[Data] Equity curve saved to equity_curve.csv")

    # 5. Statistical reports on train/test predictions
    print("\n" + "="*40)
    print("  PHASE 2: STATISTICAL ANALYSIS")
    print("="*40)
    feats_all  = build_features(df)
    target_all = build_target(df)
    pred_feats = get_prediction_features(feats_all)

    split = int(len(df) * 0.7)
    valid = target_all.notna() & pred_feats.notna().all(axis=1)

    # Retrain the pipeline on train set for stats
    pipeline = SignalPipeline()
    pipeline.fit(df.iloc[:split], verbose=False)

    # Train stats
    mask_tr = valid.iloc[:split]
    X_tr = pred_feats.iloc[:split].loc[mask_tr]
    y_tr = target_all.iloc[:split].loc[mask_tr].values
    p_tr = pipeline.predictor.predict_array(X_tr)
    statistical_report(y_tr, p_tr, "Training Data (In-Sample)")

    # Test stats
    mask_te = valid.iloc[split:]
    X_te = pred_feats.iloc[split:].loc[mask_te]
    y_te = target_all.iloc[split:].loc[mask_te].values
    p_te = pipeline.predictor.predict_array(X_te)
    statistical_report(y_te, p_te, "Test Data (Out-of-Sample)")

    # 6. Save models
    pipeline.save()
    print(f"[Models] Saved to {config.MODELS_DIR}")

    # 7. Equity curve summary
    eq = results["equity_curve"]
    print(f"\n  Equity: {eq[0]:.2f} -> {eq[-1]:.2f}  "
          f"(return: {(eq[-1]/eq[0]-1)*100:.2f}%)")

    shutdown_mt5()
    print("\n[Done] Backtest complete.")


if __name__ == "__main__":
    main()
