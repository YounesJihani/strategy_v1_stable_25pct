"""
MT5 order manager — connects to terminal, places orders with SL/TP.
"""

import MetaTrader5 as mt5
import time
from strategy import config


def init_mt5() -> bool:
    """Initialise MT5 and log in to the demo account."""
    if not mt5.initialize():
        print(f"[MT5] initialize() failed: {mt5.last_error()}")
        return False

    auth = mt5.login(
        login=config.MT5_LOGIN,
        password=config.MT5_PASSWORD,
        server=config.MT5_SERVER,
    )
    if not auth:
        print(f"[MT5] login failed: {mt5.last_error()}")
        mt5.shutdown()
        return False

    info = mt5.account_info()
    if info is None:
        print("[MT5] account_info() returned None")
        mt5.shutdown()
        return False

    print(f"[MT5] Connected — account={info.login}  balance={info.balance}  "
          f"server={info.server}")
    return True


def shutdown_mt5():
    mt5.shutdown()


def get_account_balance() -> float:
    info = mt5.account_info()
    return float(info.balance) if info else 0.0


def place_order(
    symbol: str,
    direction: int,       # +1 BUY, -1 SELL
    volume: float,
    sl: float,
    tp: float,
    comment: str = "ML_EA",
) -> dict:
    """
    Place a market order on MT5.
    Returns execution result dict.
    """
    sym_info = mt5.symbol_info(symbol)
    if sym_info is None:
        return {"error": f"Symbol {symbol} not found"}
    if not sym_info.visible:
        mt5.symbol_select(symbol, True)

    tick = mt5.symbol_info_tick(symbol)
    if tick is None:
        return {"error": "No tick data"}

    order_type = mt5.ORDER_TYPE_BUY if direction == 1 else mt5.ORDER_TYPE_SELL
    price = tick.ask if direction == 1 else tick.bid

    # Normalise volume to symbol lot step
    vol_step = sym_info.volume_step
    vol_min  = sym_info.volume_min
    vol_max  = sym_info.volume_max
    volume = max(vol_min, round(volume / vol_step) * vol_step)
    volume = min(volume, vol_max)

    request = {
        "action":    mt5.TRADE_ACTION_DEAL,
        "symbol":    symbol,
        "volume":    volume,
        "type":      order_type,
        "price":     price,
        "sl":        round(sl, sym_info.digits),
        "tp":        round(tp, sym_info.digits),
        "deviation": 20,
        "magic":     123456,
        "comment":   comment,
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }

    result = mt5.order_send(request)
    if result is None:
        return {"error": f"order_send returned None: {mt5.last_error()}"}

    return {
        "retcode": result.retcode,
        "deal":    result.deal,
        "order":   result.order,
        "volume":  result.volume,
        "price":   result.price,
        "comment": result.comment,
        "ok":      result.retcode == mt5.TRADE_RETCODE_DONE,
    }


def get_open_positions(symbol: str | None = None) -> list:
    if symbol:
        positions = mt5.positions_get(symbol=symbol)
    else:
        positions = mt5.positions_get()
    return list(positions) if positions else []


def close_position(ticket: int, symbol: str, volume: float, direction: int):
    """Close an existing position by ticket."""
    close_type = mt5.ORDER_TYPE_SELL if direction == 1 else mt5.ORDER_TYPE_BUY
    tick = mt5.symbol_info_tick(symbol)
    price = tick.bid if direction == 1 else tick.ask
    sym_info = mt5.symbol_info(symbol)

    request = {
        "action":    mt5.TRADE_ACTION_DEAL,
        "symbol":    symbol,
        "volume":    volume,
        "type":      close_type,
        "position":  ticket,
        "price":     price,
        "deviation": 20,
        "magic":     123456,
        "comment":   "ML_EA_close",
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }
    return mt5.order_send(request)
