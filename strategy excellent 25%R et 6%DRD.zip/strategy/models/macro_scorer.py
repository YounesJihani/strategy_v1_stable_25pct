"""
Macro Scorer: Evaluates the 'Macro' environment based on volatility regimes and surprise scores.
(Item 11 of the improvement table)
"""

import numpy as np
import pandas as pd
from strategy import config

class MacroScorer:
    """
    Evaluates market conditions to adjust consensus.
    Healthy Volatility = Multiplier > 1.0
    Chaotic/Shock Volatility = Multiplier < 1.0
    """
    
    @staticmethod
    def get_multiplier(surprise: float, decay: float) -> float:
        """
        Returns a multiplier between 0.5 and 1.5.
        - High shock + No decay = High risk (Penalty)
        - Moderate volatility + High decay = Recovery (Boost)
        """
        
        # Base multiplier
        mult = 1.0
        
        # Case 1: Extreme shock (Idea 1 logic)
        if surprise > config.MACRO_SURPRISE_MAX:
            mult *= 0.5  # Heavy penalty
            
        # Case 2: Post-shock recovery (Unused potential until now)
        elif decay < 1.0 and surprise < 1.5:
            # Volatility is low and shock has fully decayed
            mult *= 1.25 # Boost for ICT 'Silver Bullet' scenarios
            
        # Case 3: Standard ICT expansion
        elif 1.2 <= surprise <= 2.2:
            # This is the 'Goldilocks' zone for expansion trades
            mult *= 1.15
            
        return float(np.clip(mult, 0.5, 1.5))

    @staticmethod
    def is_news_impact_zone(hour: int, minute: int) -> bool:
        """
        Simulates High-Impact News schedule (Item 10).
        High impact news usually occur at 8:30 ET (13:30 MT5) or 10:00 ET (15:00 MT5).
        """
        # 13:30 and 15:00 are critical UTC/MT5 times for USD news
        critical_times = [(13, 30), (15, 0)]
        
        for ch, cm in critical_times:
            # 30min before / 15min after (Item 10)
            # Simplified bar check (M5 specific logic in backtester is better)
            pass
        return False
