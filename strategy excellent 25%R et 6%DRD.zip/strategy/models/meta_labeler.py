"""
Phase 4.1 — Meta-Labeling (Lopez de Prado)
A secondary binary classifier that predicts whether the GBR signal will be profitable.
Only trades with meta-probability >= threshold are executed.
Reference: "Advances in Financial Machine Learning", marcos Lopez de Prado (2018)
"""
import numpy as np
import pandas as pd
import joblib, os
from sklearn.ensemble import RandomForestClassifier
from sklearn.calibration import CalibratedClassifierCV
from strategy import config


class MetaLabeler:
    """
    Predicts if a GBR signal will be profitable (binary classification).
    Trained on (features + GBR prediction) → label = 1 if profitable, 0 otherwise.
    """

    def __init__(self, threshold: float = 0.58):
        base = RandomForestClassifier(
            n_estimators=200,
            max_depth=4,
            min_samples_leaf=20,
            class_weight="balanced",
            n_jobs=-1,
            random_state=42,
        )
        self.model      = CalibratedClassifierCV(base, cv=3, method="isotonic")
        self.threshold  = threshold
        self.is_fitted  = False
        self.feature_names: list[str] = []

    # ── Training ──────────────────────────────────────────────────

    def fit(
        self,
        X_feats: pd.DataFrame,
        y_gbr_pred: np.ndarray | pd.Series,
        y_actual: np.ndarray | pd.Series,
    ) -> "MetaLabeler":
        """
        X_feats    : raw feature matrix (same as used for GBR)
        y_gbr_pred : GBR predicted returns
        y_actual   : realized returns (forward log-returns)
        """
        gbr_pred = np.asarray(y_gbr_pred)
        actual   = np.asarray(y_actual)

        # Meta-label: 1 if GBR direction was correct AND trade profitable net of cost
        tc = config.TRANSACTION_COST_BPS * 1e-4 * 2
        profitable = (np.sign(gbr_pred) == np.sign(actual)) & (actual - tc > 0)
        meta_label = profitable.astype(int)

        # Augment features with GBR prediction info
        X_meta = X_feats.copy().reset_index(drop=True)
        X_meta["gbr_pred"]  = gbr_pred
        X_meta["gbr_sign"]  = np.sign(gbr_pred)
        X_meta["gbr_mag"]   = np.abs(gbr_pred)

        # Drop NaN rows aligned with meta_label
        mask = pd.Series(meta_label).notna() & X_meta.notna().all(axis=1)
        X_clean = X_meta.loc[mask].values
        y_clean = meta_label[mask.values]

        if len(y_clean) < 50 or y_clean.sum() < 10:
            # Not enough positive labels — can't calibrate meaningfully
            self.is_fitted = False
            return self

        self.feature_names = list(X_meta.columns)
        self.model.fit(X_clean, y_clean)
        self.is_fitted = True
        return self

    # ── Inference ─────────────────────────────────────────────────

    def predict_proba(
        self,
        X_feats: pd.DataFrame,
        gbr_pred: float,
    ) -> float:
        """
        Returns the probability that the signal will be profitable.
        """
        if not self.is_fitted:
            return 1.0   # pass-through if not trained yet

        X_meta = X_feats.copy()
        X_meta["gbr_pred"] = gbr_pred
        X_meta["gbr_sign"] = np.sign(gbr_pred)
        X_meta["gbr_mag"]  = abs(gbr_pred)

        # Align to training feature order
        X_row = X_meta[self.feature_names].values[-1:].reshape(1, -1)
        proba = self.model.predict_proba(X_row)
        return float(proba[0, 1])   # P(profitable)

    def passes(
        self,
        X_feats: pd.DataFrame,
        gbr_pred: float,
    ) -> tuple[bool, float]:
        """Returns (gate_open, probability)."""
        prob = self.predict_proba(X_feats, gbr_pred)
        return prob >= self.threshold, prob

    # ── Persistence ───────────────────────────────────────────────

    def save(self, path: str | None = None):
        path = path or os.path.join(config.MODELS_DIR, "meta_labeler.pkl")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        joblib.dump(
            {"model": self.model, "features": self.feature_names,
             "threshold": self.threshold, "is_fitted": self.is_fitted},
            path,
        )

    def load(self, path: str | None = None) -> "MetaLabeler":
        path = path or os.path.join(config.MODELS_DIR, "meta_labeler.pkl")
        if not os.path.exists(path):
            return self
        data = joblib.load(path)
        self.model         = data["model"]
        self.feature_names = data["features"]
        self.threshold     = data.get("threshold", self.threshold)
        self.is_fitted     = data.get("is_fitted", True)
        return self
