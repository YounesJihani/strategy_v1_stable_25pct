"""
ICT Precision Entry — Master Spec V2
Patterns chirurgicaux : Unicorn, Silver Bullet, OTE.
Score composite MTF intégrant M5 + H1 + H4.
"""

import numpy as np
import pandas as pd


def detect_unicorn(df: pd.DataFrame, feats: pd.DataFrame) -> pd.Series:
    """
    UNICORN SETUP — Le plus puissant.
    MSS (Market Structure Shift) + FVG créé + Kill Zone active.
    Win Rate attendu seul : 65%+
    Retourne : +1.0 (bull), -1.0 (bear), 0.0 (pas de setup).
    """
    close = df["close"].astype(float)
    high  = df["high"].astype(float)
    low   = df["low"].astype(float)
    score = pd.Series(0.0, index=df.index)

    # MSS : cassure d'un swing des 10 dernières barres
    prev_h = high.rolling(10).max().shift(2)
    prev_l = low.rolling(10).min().shift(2)
    mss_bull = close > prev_h
    mss_bear = close < prev_l

    # FVG créé dans les 3 barres après le MSS
    fvg_bull_bool = feats["fvg_bull"].astype(bool) if "fvg_bull" in feats.columns else (close > close)
    fvg_bear_bool = feats["fvg_bear"].astype(bool) if "fvg_bear" in feats.columns else (close > close)
    fvg_after_bull = fvg_bull_bool & mss_bull.shift(1).fillna(False).rolling(3).max().astype(bool)
    fvg_after_bear = fvg_bear_bool & mss_bear.shift(1).fillna(False).rolling(3).max().astype(bool)

    # Kill Zone obligatoire
    kz = feats["in_killzone"].astype(bool) if "in_killzone" in feats.columns else pd.Series(True, index=df.index)

    score[mss_bull & fvg_after_bull & kz] =  1.0
    score[mss_bear & fvg_after_bear & kz] = -1.0
    return score


def detect_silver_bullet(df: pd.DataFrame, feats: pd.DataFrame) -> pd.Series:
    """
    SILVER BULLET SETUP.
    3 fenêtres d'1h par jour : FVG pendant la fenêtre + Stop Hunt = entrée chirurgicale.
    Fenêtres (UTC) : 03–04h | 10–11h | 14–15h.
    """
    close = df["close"].astype(float)
    score = pd.Series(0.0, index=df.index)

    if "time" not in df.columns:
        return score

    ts   = pd.to_datetime(df["time"])
    hour = ts.dt.hour + ts.dt.minute / 60.0

    # 3 fenêtres Silver Bullet
    sb = (
        ((3.0  <= hour) & (hour < 4.0))  |
        ((10.0 <= hour) & (hour < 11.0)) |
        ((14.0 <= hour) & (hour < 15.0))
    )

    fvg_bull_bool = feats["fvg_bull"].astype(bool) if "fvg_bull" in feats.columns else pd.Series(False, index=df.index)
    fvg_bear_bool = feats["fvg_bear"].astype(bool) if "fvg_bear" in feats.columns else pd.Series(False, index=df.index)
    sh_bull = feats["stop_hunt_bull"].astype(bool) if "stop_hunt_bull" in feats.columns else pd.Series(False, index=df.index)
    sh_bear = feats["stop_hunt_bear"].astype(bool) if "stop_hunt_bear" in feats.columns else pd.Series(False, index=df.index)

    fvg_in_sb_bull  = fvg_bull_bool & sb
    fvg_in_sb_bear  = fvg_bear_bool & sb
    fvg_recent_bull = fvg_in_sb_bull.rolling(12).max().astype(bool)
    fvg_recent_bear = fvg_in_sb_bear.rolling(12).max().astype(bool)

    score[fvg_recent_bull & sh_bull & sb] =  1.0
    score[fvg_recent_bear & sh_bear & sb] = -1.0
    return score


def detect_ote(df: pd.DataFrame, feats: pd.DataFrame) -> pd.Series:
    """
    OTE SETUP — Optimal Trade Entry.
    Retracement Fibonacci 61.8%–78.6% après displacement + Kill Zone.
    Le plus reproductible des 3 setups.
    """
    score = pd.Series(0.0, index=df.index)

    ote_bull = feats["ote_bull"].astype(bool) if "ote_bull" in feats.columns else pd.Series(False, index=df.index)
    ote_bear = feats["ote_bear"].astype(bool) if "ote_bear" in feats.columns else pd.Series(False, index=df.index)
    disp     = feats["displacement"].astype(bool) if "displacement" in feats.columns else pd.Series(False, index=df.index)
    kz       = feats["in_killzone"].astype(bool) if "in_killzone" in feats.columns else pd.Series(True, index=df.index)

    disp_dir     = feats["disp_dir"] if "disp_dir" in feats.columns else pd.Series(0.0, index=df.index)
    displaced    = disp.rolling(5).max().astype(bool)
    disp_dir_avg = disp_dir.rolling(5).mean()
    disp_bull    = displaced & (disp_dir_avg > 0)
    disp_bear    = displaced & (disp_dir_avg < 0)

    score[ote_bull & disp_bull & kz] =  1.0
    score[ote_bear & disp_bear & kz] = -1.0
    return score


def surgical_score_mtf(df: pd.DataFrame, feats: pd.DataFrame) -> pd.DataFrame:
    """
    Score Chirurgical Composite MTF.
    - 60% score M5 (Unicorn 45% + Silver Bullet 35% + OTE 20%)
    - 40% bonus MTF (H4+H1 bias, PD zone, FVG H1, KZ×MTF)
    Retourne : DataFrame avec colonnes bull_final, bear_final [0→1].
    """
    unicorn = detect_unicorn(df, feats)
    silver  = detect_silver_bullet(df, feats)
    ote     = detect_ote(df, feats)

    res = pd.DataFrame(index=df.index)

    # Score chirurgical M5
    res["bull_m5"] = (
        (unicorn ==  1).astype(float) * 0.45 +
        (silver  ==  1).astype(float) * 0.35 +
        (ote     ==  1).astype(float) * 0.20
    )
    res["bear_m5"] = (
        (unicorn == -1).astype(float) * 0.45 +
        (silver  == -1).astype(float) * 0.35 +
        (ote     == -1).astype(float) * 0.20
    )

    # Bonus MTF — alignement H1 + H4
    def _get(col, default=0.0):
        return feats[col].astype(float) if col in feats.columns else pd.Series(default, index=df.index)

    mtf_bull_bonus = (
        _get("mtf_bull")      * 0.40 +
        _get("h4_in_discount")* 0.25 +
        _get("h1_fvg_bull")   * 0.20 +
        _get("kz_mtf_bull")   * 0.15
    )
    mtf_bear_bonus = (
        _get("mtf_bear")      * 0.40 +
        _get("h4_in_premium") * 0.25 +
        _get("h1_fvg_bear")   * 0.20 +
        _get("kz_mtf_bear")   * 0.15
    )

    # Score final : 60% chirurgical M5 + 40% MTF
    res["bull_final"] = (res["bull_m5"] * 0.60 + mtf_bull_bonus * 0.40).clip(0, 1)
    res["bear_final"] = (res["bear_m5"] * 0.60 + mtf_bear_bonus * 0.40).clip(0, 1)

    return res
