"""
ict_features.py
----------------
Computes Smart Money Concepts (ICT) features:
- Market Structure (HH, HL, LH, LL, BOS, CHOCH)
- Fair Value Gaps (FVG)
- Order Blocks (OB)
- Liquidity Sweeps
- ICT Kill Zones
"""

import numpy as np
import pandas as pd

def compute_ict_features(df: pd.DataFrame) -> pd.DataFrame:
    close = df["close"].astype(float)
    high  = df["high"].astype(float)
    low   = df["low"].astype(float)
    open_ = df["open"].astype(float)
    
    feats = pd.DataFrame(index=df.index)
    
    # 1. Fair Value Gaps (FVG)
    # Bullish FVG: low[t] > high[t-2]
    # Bearish FVG: high[t] < low[t-2]
    feats["ict_fvg_bull"] = (low - high.shift(2)).clip(lower=0)
    feats["ict_fvg_bear"] = (low.shift(2) - high).clip(lower=0)
    
    # 2. Market Structure (Simplified)
    # Local extremes (window=5)
    roll_high = high.rolling(5, center=True).max()
    roll_low  = low.rolling(5, center=True).min()
    
    is_hh = (high == roll_high) & (high > high.shift(5))
    is_ll = (low == roll_low) & (low < low.shift(5))
    
    feats["ict_hh"] = is_hh.astype(float)
    feats["ict_ll"] = is_ll.astype(float)
    
    # 3. Liquidity Sweeps
    # Price breaks recent high/low then reverses
    lookback = 20
    prev_high = high.rolling(lookback).max().shift(1)
    prev_low  = low.rolling(lookback).min().shift(1)
    
    sweep_buy = (high > prev_high) & (close < prev_high)
    sweep_sell = (low < prev_low) & (close > prev_low)
    
    feats["ict_sweep_buy"] = sweep_buy.astype(float)
    feats["ict_sweep_sell"] = sweep_sell.astype(float)
    
    # 4. Order Blocks (OB) - Simple volume-based
    # Bullish OB: Last down candle before a strong up move
    # Bearish OB: Last up candle before a strong down move
    up_move = (close > open_) & (close.diff(1) > 0)
    dn_move = (close < open_) & (close.diff(1) < 0)
    
    # Displacement check for OB validity
    atr = (high - low).rolling(14).mean()
    displacement = (close.diff(1).abs() > atr).astype(float)
    
    feats["ict_ob_bull"] = ((close.shift(1) < open_.shift(1)) & up_move & displacement).astype(float)
    feats["ict_ob_bear"] = ((close.shift(1) > open_.shift(1)) & dn_move & displacement).astype(float)
    
    # 5. Kill Zones (UTC)
    if "time" in df.columns:
        hours = pd.to_datetime(df["time"]).dt.hour
        feats["ict_kz_london"] = ((hours >= 7) & (hours <= 10)).astype(float)
        feats["ict_kz_newyork"] = ((hours >= 13) & (hours <= 16)).astype(float)
        feats["ict_kz_asia"] = ((hours >= 0) & (hours <= 4)).astype(float)
    else:
        feats["ict_kz_london"] = 0.0
        feats["ict_kz_newyork"] = 0.0
        feats["ict_kz_asia"] = 0.0

    return feats.fillna(0)
