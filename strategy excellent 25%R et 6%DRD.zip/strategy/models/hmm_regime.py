"""
Phase 4.2 — HMM Regime Detection (replaces/complements IsolationForest)
Uses a 3-state Gaussian HMM to detect BEARISH / RANGING / BULLISH regimes.
Conditions trade direction on detected regime for directional coherence.

Requires: pip install hmmlearn
"""
import numpy as np
import pandas as pd
import joblib, os

from strategy import config

try:
    from hmmlearn import hmm as _hmm_lib
    _HMM_AVAILABLE = True
except ImportError:
    _HMM_AVAILABLE = False


# Features used for HMM regime detection — kept lightweight
HMM_FEATURES = ["logret_1", "vol_20", "atr_norm", "vol_rel"]


class HMMRegimeDetector:
    """
    Detects market regime via a 3-state Gaussian HMM.
    States: 0=BEARISH, 1=RANGING, 2=BULLISH
    """

    REGIME_NAMES = {0: "BEARISH", 1: "RANGING", 2: "BULLISH"}

    def __init__(self, n_states: int = 3):
        self.n_states       = n_states
        self.is_fitted      = False
        self.bullish_state  = 2
        self.bearish_state  = 0
        self.ranging_state  = 1
        self._model         = None

    def _build_model(self):
        if not _HMM_AVAILABLE:
            return None
        return _hmm_lib.GaussianHMM(
            n_components=self.n_states,
            covariance_type="full",
            n_iter=200,
            tol=1e-4,
            random_state=42,
        )

    # ── Training ──────────────────────────────────────────────────

    def fit(self, feats: pd.DataFrame) -> "HMMRegimeDetector":
        """
        feats : DataFrame containing at minimum the HMM_FEATURES columns.
        """
        if not _HMM_AVAILABLE:
            print("[HMM] hmmlearn not installed — regime detection disabled. "
                  "Install with: pip install hmmlearn")
            return self

        cols = [c for c in HMM_FEATURES if c in feats.columns]
        if not cols:
            return self

        X = feats[cols].dropna().values.astype(float)
        if len(X) < 500:
            return self   # not enough data

        self._model = self._build_model()
        self._model.fit(X)

        # Identify states by mean log-return of each HMM state
        states = self._model.predict(X)
        logret_col = feats["logret_1"].dropna().values[-len(X):]
        returns_by_state = {}
        for s in range(self.n_states):
            mask = states == s
            returns_by_state[s] = float(logret_col[mask].mean()) if mask.sum() > 0 else 0.0

        sorted_states = sorted(returns_by_state, key=returns_by_state.get)
        self.bearish_state = sorted_states[0]
        self.ranging_state = sorted_states[1]
        self.bullish_state = sorted_states[2]

        self.is_fitted = True
        return self

    # ── Inference ─────────────────────────────────────────────────

    def predict_regime(self, feats: pd.DataFrame) -> tuple[str, int, float]:
        """
        Returns (regime_name, state_id, probability).
        Falls back to RANGING if HMM not fitted.
        """
        if not self.is_fitted or self._model is None:
            return "RANGING", 1, 0.5

        cols = [c for c in HMM_FEATURES if c in feats.columns]
        X = feats[cols].dropna().values.astype(float)
        if len(X) == 0:
            return "RANGING", 1, 0.5

        predicted_states = self._model.predict(X)
        state = int(predicted_states[-1])
        state_proba = float(self._model.predict_proba(X)[-1, state])

        # Map internal HMM state to BEARISH/RANGING/BULLISH
        regime_id_map = {
            self.bearish_state: 0,
            self.ranging_state: 1,
            self.bullish_state: 2,
        }
        regime_id   = regime_id_map.get(state, 1)
        regime_name = self.REGIME_NAMES[regime_id]

        return regime_name, regime_id, state_proba

    def is_tradable(
        self,
        feats: pd.DataFrame,
        required_direction: int,
        min_proba: float = 0.70,
    ) -> tuple[bool, str]:
        """
        Returns (can_trade, reason_string).
        Blocks:
          - Shorts in confirmed BULLISH regime (proba > min_proba)
          - Longs  in confirmed BEARISH regime (proba > min_proba)
        RANGING regime allows both directions.
        """
        regime, regime_id, proba = self.predict_regime(feats)

        if regime == "BULLISH" and required_direction == -1 and proba >= min_proba:
            return False, f"HMM: Bullish regime blocks short (proba={proba:.2f})"
        if regime == "BEARISH" and required_direction == 1 and proba >= min_proba:
            return False, f"HMM: Bearish regime blocks long (proba={proba:.2f})"

        return True, f"HMM: {regime} (proba={proba:.2f})"

    # ── Persistence ───────────────────────────────────────────────

    def save(self, path: str | None = None):
        path = path or os.path.join(config.MODELS_DIR, "hmm_regime.pkl")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        joblib.dump({
            "model": self._model,
            "bullish": self.bullish_state,
            "bearish": self.bearish_state,
            "ranging": self.ranging_state,
            "is_fitted": self.is_fitted,
        }, path)

    def load(self, path: str | None = None) -> "HMMRegimeDetector":
        path = path or os.path.join(config.MODELS_DIR, "hmm_regime.pkl")
        if not os.path.exists(path):
            return self
        data = joblib.load(path)
        self._model        = data["model"]
        self.bullish_state = data["bullish"]
        self.bearish_state = data["bearish"]
        self.ranging_state = data["ranging"]
        self.is_fitted     = data.get("is_fitted", True)
        return self
