"""
Phase 4.4 — Purged Walk-Forward Cross-Validation (Lopez de Prado)
Adds a configurable purge gap between train and validation windows to eliminate
residual autocorrelation between adjacent splits.
Reference: "Advances in Financial Machine Learning", Chapter 7.
"""
import numpy as np
import pandas as pd
import lightgbm as lgb
from strategy import config


class WalkForwardValidator:
    """
    Purged Walk-Forward Validation with configurable purge gap.

    Architecture:
        [  TRAIN WINDOW  ][GAP][  VALIDATION WINDOW  ]

    The purge gap (default: config.WF_PURGE_BARS = 6 bars) prevents
    autocorrelation leakage from trailing into the validation window.
    This results in conservative but honest out-of-sample performance estimates.
    """

    def __init__(self):
        self.n_windows = config.WF_WINDOWS

    def score(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        prices: pd.Series,
        purge_bars: int | None = None,
    ) -> float:
        """
        Run purged walk-forward validation.
        Returns average win-rate across windows (0–1).

        purge_bars: Bars to drop between train end and validation start.
                    Defaults to config.WF_PURGE_BARS (typically 6).
        """
        if purge_bars is None:
            purge_bars = getattr(config, "WF_PURGE_BARS", 6)

        n = len(X)

        # ── Bars-per-day by timeframe ──────────────────────────────
        tf_name = config.MT5_TIMEFRAME_NAME
        bph_map = {"M1": 60, "M5": 12, "M15": 4, "M30": 2, "H1": 1}
        bars_per_hour = bph_map.get(tf_name, 12)
        bars_per_day  = bars_per_hour * 16          # ~16 Forex trading hours/day

        train_len    = config.WF_TRAIN_DAYS * bars_per_day
        val_len      = config.WF_VAL_DAYS   * bars_per_day
        window_total = train_len + purge_bars + val_len

        if n < window_total:
            # Not enough data — degrade gracefully
            return 0.0

        scores = []
        for i in range(self.n_windows):
            # Walk backward from the end
            val_end   = n - i * val_len
            val_start = val_end - val_len
            # Apply purge gap BEFORE validation
            tr_end    = val_start - purge_bars
            tr_start  = max(0, tr_end - train_len)

            if tr_start >= tr_end or val_start >= val_end or tr_end <= 0:
                continue

            X_tr = X.iloc[tr_start:tr_end]
            y_tr = y.iloc[tr_start:tr_end]
            X_vl = X.iloc[val_start:val_end]
            y_vl = y.iloc[val_start:val_end]

            mask_tr = y_tr.notna() & X_tr.notna().all(axis=1)
            mask_vl = y_vl.notna() & X_vl.notna().all(axis=1)

            if mask_tr.sum() < 100 or mask_vl.sum() < 20:
                continue

            # Use LightGBM (Phase 3.1) for all WF sub-models — consistent with main model
            lgbm_params = {
                "n_estimators":    min(100, config.LGBM_PARAMS.get("n_estimators", 100)),
                "max_depth":       config.LGBM_PARAMS.get("max_depth", 4),
                "learning_rate":   config.LGBM_PARAMS.get("learning_rate", 0.05),
                "num_leaves":      config.LGBM_PARAMS.get("num_leaves", 31),
                "subsample":       config.LGBM_PARAMS.get("subsample", 0.8),
                "colsample_bytree":config.LGBM_PARAMS.get("colsample_bytree", 0.8),
                "random_state":    42,
                "verbosity":       -1,
                "n_jobs":          -1,
            }
            model = lgb.LGBMRegressor(**lgbm_params)
            model.fit(
                X_tr.loc[mask_tr].values,
                y_tr.loc[mask_tr].values,
            )
            preds   = model.predict(X_vl.loc[mask_vl].values)
            actuals = y_vl.loc[mask_vl].values

            # Directional win-rate
            dir_correct = np.sign(preds) == np.sign(actuals)
            win_rate    = float(dir_correct.mean())

            # Profit factor
            gross_profit = float(np.sum(actuals[(preds > 0) & (actuals > 0)]))
            gross_loss   = float(abs(np.sum(actuals[(preds > 0) & (actuals < 0)]))) + 1e-12
            pf = gross_profit / gross_loss

            passed = (win_rate >= config.WF_MIN_WINRATE) and (pf >= config.WF_MIN_PF)
            scores.append(win_rate if passed else win_rate * 0.5)

        if not scores:
            return 0.0
        return float(np.mean(scores))
