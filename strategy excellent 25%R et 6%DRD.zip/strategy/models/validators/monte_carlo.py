"""
Monte Carlo Feature-Dropout Validation.
Trains N models each with a random 70% subset of features and checks agreement.
"""

import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor
from strategy import config


class MonteCarloValidator:
    """Simulates MC Dropout via feature subsampling."""

    # Lightweight params for sub-models (speed)
    _FAST_GBR = dict(
        n_estimators=30, max_depth=3, learning_rate=0.1,
        subsample=0.8, min_samples_split=20, min_samples_leaf=10,
        random_state=42,
    )

    def __init__(self):
        self.n_models = config.MC_N_MODELS
        self.feature_frac = config.MC_FEATURE_FRAC
        self.models: list = []
        self.feature_subsets: list[list[str]] = []

    def fit(self, X: pd.DataFrame, y: pd.Series):
        """Train n_models, each on a random subset of features."""
        mask = y.notna() & X.notna().all(axis=1)
        X_c, y_c = X.loc[mask], y.loc[mask]
        all_feats = list(X_c.columns)
        n_select = max(1, int(len(all_feats) * self.feature_frac))
        rng = np.random.RandomState(42)

        # Subsample for speed in validators
        if len(X_c) > 10000:
            samp_idx = rng.choice(len(X_c), 10000, replace=False)
            X_c, y_c = X_c.iloc[samp_idx], y_c.iloc[samp_idx]

        self.models = []
        self.feature_subsets = []
        for i in range(self.n_models):
            cols = list(rng.choice(all_feats, size=n_select, replace=False))
            self.feature_subsets.append(cols)
            m = GradientBoostingRegressor(**self._FAST_GBR)
            m.fit(X_c[cols].values, y_c.values)
            self.models.append(m)
            print(f"    MC model {i+1}/{self.n_models}", end="\r", flush=True)
        print(f"    MC: {self.n_models} models trained.       ", flush=True)
        return self

    def score(self, X_row: pd.DataFrame) -> float:
        """
        Score a single observation (last row of X_row).
        Returns proportion of models agreeing on the majority direction.
        """
        row = X_row.iloc[[-1]]
        preds = np.array([m.predict(row[cols].values)[0] for m, cols in zip(self.models, self.feature_subsets)])

        preds = np.array(preds)
        mean_pred = preds.mean()
        std_pred  = preds.std()

        if abs(mean_pred) < 1e-12:
            return 0.0

        majority_dir = np.sign(mean_pred)
        agreement = (np.sign(preds) == majority_dir).mean()

        # Extra check: std must be small relative to |mean|
        if std_pred > config.MC_STD_RATIO_MAX * abs(mean_pred):
            agreement *= 0.5          # penalise uncertain consensus

        return float(agreement)

    def direction(self, X_row: pd.DataFrame) -> int:
        row = X_row.iloc[[-1]]
        preds = np.array([m.predict(row[cols].values)[0] for m, cols in zip(self.models, self.feature_subsets)])
        return int(np.sign(np.mean(preds)))

    def score_batch(self, X: pd.DataFrame) -> pd.Series:
        """Batch score for massive speedup."""
        all_preds = []
        for m, cols in zip(self.models, self.feature_subsets):
            all_preds.append(m.predict(X[cols].values))
        
        all_preds = np.array(all_preds) # (n_models, n_samples)
        mean_preds = np.mean(all_preds, axis=0)
        std_preds  = np.std(all_preds, axis=0)
        
        maj_dir = np.sign(mean_preds)
        agreement = np.mean(np.sign(all_preds) == maj_dir[None, :], axis=0)
        
        # Penalty for high std
        ratio_mask = std_preds > (config.MC_STD_RATIO_MAX * np.abs(mean_preds))
        agreement[ratio_mask] *= 0.5
        
        return pd.Series(agreement, index=X.index)

    def direction_batch(self, X: pd.DataFrame) -> pd.Series:
        all_preds = np.array([m.predict(X[cols].values) for m, cols in zip(self.models, self.feature_subsets)])
        return pd.Series(np.sign(np.mean(all_preds, axis=0)).astype(int), index=X.index)
    def save(self):
        import joblib, os
        path = os.path.join(config.MODELS_DIR, "mc_validator.joblib")
        os.makedirs(config.MODELS_DIR, exist_ok=True)
        joblib.dump({"models": self.models, "feature_subsets": self.feature_subsets}, path)

    def load(self):
        import joblib, os
        path = os.path.join(config.MODELS_DIR, "mc_validator.joblib")
        if os.path.exists(path):
            data = joblib.load(path)
            self.models = data["models"]
            self.feature_subsets = data["feature_subsets"]
            self.n_models = len(self.models)
        return self
