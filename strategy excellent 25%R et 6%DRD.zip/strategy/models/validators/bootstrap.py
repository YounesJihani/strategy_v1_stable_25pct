"""
Bootstrap Validation — trains N models on bootstrapped samples
and evaluates directional agreement on the current point.
"""

import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor
from strategy import config


class BootstrapValidator:
    """Bootstrap models for directional confidence estimation."""

    # Lightweight params for sub-models (speed)
    _FAST_GBR = dict(
        n_estimators=30, max_depth=3, learning_rate=0.1,
        subsample=0.8, min_samples_split=20, min_samples_leaf=10,
        random_state=42,
    )

    def __init__(self):
        self.n_samples = config.BS_N_SAMPLES
        self.models: list = []
        self.feature_names: list[str] = []

    def fit(self, X: pd.DataFrame, y: pd.Series):
        mask = y.notna() & X.notna().all(axis=1)
        X_c, y_c = X.loc[mask], y.loc[mask]
        self.feature_names = list(X_c.columns)
        rng = np.random.RandomState(42)

        # Subsample for speed in validators
        if len(X_c) > 10000:
            samp_idx = rng.choice(len(X_c), 10000, replace=False)
            X_c, y_c = X_c.iloc[samp_idx], y_c.iloc[samp_idx]

        n = len(X_c)
        self.models = []
        for i in range(self.n_samples):
            idx = rng.choice(n, size=n, replace=True)
            m = GradientBoostingRegressor(**self._FAST_GBR)
            m.fit(X_c.values[idx], y_c.values[idx])
            self.models.append(m)
            print(f"    BS model {i+1}/{self.n_samples}", end="\r", flush=True)
        print(f"    BS: {self.n_samples} models trained.       ", flush=True)
        return self

    def score(self, X_row: pd.DataFrame) -> float:
        """
        Returns P(prediction in same direction as central prediction).
        Also checks that 95 % CI bounds share the same sign.
        """
        row = X_row.iloc[[-1]][self.feature_names].values
        preds = np.array([m.predict(row)[0] for m in self.models])

        central = np.median(preds)
        if abs(central) < 1e-12:
            return 0.0

        direction = np.sign(central)
        agreement = (np.sign(preds) == direction).mean()

        # 95% CI check — both bounds must share sign
        lo, hi = np.percentile(preds, [2.5, 97.5])
        if np.sign(lo) != np.sign(hi):
            agreement *= 0.5       # penalise split CI

        return float(agreement)

    def score_batch(self, X: pd.DataFrame) -> pd.Series:
        X_vals = X[self.feature_names].values
        all_preds = np.array([m.predict(X_vals) for m in self.models]) # (n_models, n_samples)
        
        central = np.median(all_preds, axis=0)
        direction = np.sign(central)
        agreement = np.mean(np.sign(all_preds) == direction[None, :], axis=0)
        
        lo, hi = np.percentile(all_preds, [2.5, 97.5], axis=0)
        split_mask = np.sign(lo) != np.sign(hi)
        agreement[split_mask] *= 0.5
        
        return pd.Series(agreement, index=X.index)

    def direction_batch(self, X: pd.DataFrame) -> pd.Series:
        X_vals = X[self.feature_names].values
        all_preds = np.array([m.predict(X_vals) for m in self.models])
        return pd.Series(np.sign(np.median(all_preds, axis=0)).astype(int), index=X.index)

    def direction(self, X_row: pd.DataFrame) -> int:
        row = X_row.iloc[[-1]][self.feature_names].values
        preds = np.array([m.predict(row)[0] for m in self.models])
        return int(np.sign(np.median(preds)))

    def save(self):
        import joblib, os
        path = os.path.join(config.MODELS_DIR, "bs_validator.joblib")
        os.makedirs(config.MODELS_DIR, exist_ok=True)
        joblib.dump({"models": self.models, "feature_names": self.feature_names}, path)

    def load(self):
        import joblib, os
        path = os.path.join(config.MODELS_DIR, "bs_validator.joblib")
        if os.path.exists(path):
            data = joblib.load(path)
            self.models = data["models"]
            self.feature_names = data["feature_names"]
            self.n_samples = len(self.models)
        return self

