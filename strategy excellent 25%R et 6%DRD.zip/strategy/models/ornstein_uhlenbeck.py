import numpy as np
import pandas as pd
from scipy.stats import linregress

class OrnsteinUhlenbeck:
    """
    Validates ICT concepts (FVG, OB) using Ornstein-Uhlenbeck Mean-Reverting Process.
    Formula: dx_t = theta * (mu - x_t) * dt + sigma * dW_t
    
    Attributes:
        theta (float): Speed of mean reversion (Force de rappel).
        mu (float): Long-term mean (Niveau d'équilibre / Fair Value).
        sigma (float): Volatility of the process.
    """

    def __init__(self, window: int = 20):
        self.window = window

    def fit(self, price_series: pd.Series) -> dict:
        """
        Calibre le processus OU sur une fenêtre glissante.
        Retourne theta, mu, sigma et half_life.
        """
        # Formating for regression: x(t+1) - x(t) vs x(t)
        x_t = price_series.values[:-1]
        dx_t = price_series.diff().values[1:]
        
        # Regress dx_t against x_t to find theta and mu
        # dx_t = theta*mu*dt - theta*x_t*dt + sigma*dW_t
        # Linear form: y = alpha + beta * x + epsilon
        # beta = -theta * dt
        # alpha = theta * mu * dt
        
        res = linregress(x_t, dx_t)
        beta = res.slope
        alpha = res.intercept
        
        # Assuming dt = 1 (time step) for simplicity in M5 bars
        dt = 1.0
        
        theta = -beta / dt
        
        if theta <= 1e-6: # Prevent division by zero or non-mean-reverting
            return {
                "theta": 0.0,
                "mu": price_series.mean(),
                "sigma": 0.0,
                "half_life": 9999.0,
                "r_squared": res.rvalue**2
            }
            
        mu = alpha / (theta * dt)
        
        # Calculate residuals for sigma
        residuals = dx_t - (alpha + beta * x_t)
        sigma = np.std(residuals)
        
        half_life = np.log(2) / theta if theta > 0 else 9999.0
        
        return {
            "theta": theta,
            "mu": mu,
            "sigma": sigma,
            "half_life": half_life,
            "r_squared": res.rvalue**2
        }

    def compute_z_score(self, current_price: float, mu: float, sigma: float) -> float:
        """
        Calcule le Z-Score (distance normalisée par la volatilité).
        Z = (Price - FairValue) / Sigma
        """
        if sigma < 1e-9: return 0.0
        return (current_price - mu) / sigma

def validate_ict_setup(price_series: pd.Series, fair_value_level: float) -> dict:
    """
    Wrapper rapide pour valider un setup ICT spécifique.
    """
    model = OrnsteinUhlenbeck(window=len(price_series))
    params = model.fit(price_series)
    
    # Force Mu to be the ICT Fair Value (assuming strict mean reversion to that level)
    # Or compare calculated Mu with ICT Mu to check alignment
    
    alignment_score = 1.0 - (abs(params['mu'] - fair_value_level) / fair_value_level)
    z_score = model.compute_z_score(price_series.iloc[-1], params['mu'], params['sigma'])
    
    return {
        "ou_theta": params['theta'],
        "ou_half_life": params['half_life'],
        "ou_z_score": z_score,
        "ou_sigma": params['sigma'],
        "alignment": alignment_score
    }
