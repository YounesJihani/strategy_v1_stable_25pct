"""
GradientBoosting — ACTION 2 : LightGBM Classifier (direction uniquement).

Changements clés vs ancienne version :
  - Régression → Classification ternaire filtée : Long (+1), Short (-1)
  - Les barres neutres (y=0) sont exclues de l'entraînement
  - predict() retourne (direction, confidence) au lieu d'un "predicted_return"
  - Filtre de confiance : n'exécute que si confidence > config.LGBM_CONF_MIN
"""

import numpy as np
import pandas as pd
import lightgbm as lgb
import joblib, os
from strategy import config


class ReturnPredictor:
    """
    LightGBM Classifier : prédit la direction (Long/Short) avec une probabilité.
    Entraîné uniquement sur les barres 'significatives' (|return| > seuil dynamique).
    """

    def __init__(self):
        self.model = lgb.LGBMClassifier(
            n_estimators      = config.LGBM_PARAMS.get("n_estimators", 400),
            max_depth         = config.LGBM_PARAMS.get("max_depth", 4),
            learning_rate     = config.LGBM_PARAMS.get("learning_rate", 0.02),
            num_leaves        = config.LGBM_PARAMS.get("num_leaves", 16),
            subsample         = config.LGBM_PARAMS.get("subsample", 0.75),
            colsample_bytree  = config.LGBM_PARAMS.get("colsample_bytree", 0.75),
            min_child_samples = config.LGBM_PARAMS.get("min_child_samples", 40),
            class_weight      = "balanced",
            reg_alpha         = config.LGBM_PARAMS.get("reg_alpha", 0.15),
            reg_lambda        = config.LGBM_PARAMS.get("reg_lambda", 0.25),
            random_state      = 42,
            verbosity         = -1,
            n_jobs            = -1,
        )
        self.is_fitted       = False
        self.feature_names: list[str] = []
        self.transaction_cost = config.TRANSACTION_COST_BPS * 1e-4
        self.conf_min         = getattr(config, "LGBM_CONF_MIN", 0.60)  # 60% min — Master Spec V2

    # ── fit / predict ──────────────────────────────────────────────

    def fit(self, X: pd.DataFrame, y: pd.Series):
        """
        y est le target de classification : +1, 0, -1.
        Les barres neutres (y==0) sont exclues — moins de bruit = meilleure précision.
        """
        mask   = y.notna() & X.notna().all(axis=1)
        X_all  = X.loc[mask]
        y_all  = y.loc[mask]

        # Exclure les barres neutres (ACTION 1 — seuil dynamique)
        non_neutral = y_all != 0
        X_clean = X_all.loc[non_neutral]
        y_clean = y_all.loc[non_neutral]

        n_neutral = int((~non_neutral).sum())
        n_used    = int(non_neutral.sum())
        print(f"  [Classifier] Barres neutres exclues : {n_neutral} | Entraînement sur : {n_used}")

        self.feature_names = list(X_clean.columns)
        self.model.fit(X_clean.values, y_clean.values)
        self.is_fitted = True
        return self

    def predict(self, X: pd.DataFrame) -> dict:
        """Retourne direction + confidence + p_bull/p_bear (dernière ligne de X)."""
        Xv      = X[self.feature_names].values
        proba   = self.model.predict_proba(Xv)
        classes = list(self.model.classes_)

        p         = proba[-1]
        idx_long  = classes.index(1)  if  1 in classes else 1
        idx_short = classes.index(-1) if -1 in classes else 0

        p_bull = float(p[idx_long])
        p_bear = float(p[idx_short])
        direction  = 1 if p_bull >= p_bear else -1
        confidence = float(max(p_bull, p_bear))

        return {
            "predicted_return" : (p_bull - p_bear),
            "signal_direction" : direction,
            "signal_magnitude" : (confidence - 0.5) / 0.5,
            "confidence"       : confidence,
            "p_bull"           : p_bull,
            "p_bear"           : p_bear,
        }

    def predict_array(self, X: pd.DataFrame) -> np.ndarray:
        """Retourne un tableau de (p_long - p_short) pour toutes les lignes."""
        Xv = X[self.feature_names].values
        proba   = self.model.predict_proba(Xv)
        classes = list(self.model.classes_)
        idx_long  = classes.index(1)  if  1 in classes else 1
        idx_short = classes.index(-1) if -1 in classes else 0
        return proba[:, idx_long] - proba[:, idx_short]

    def predict_batch(self, X: pd.DataFrame) -> list[dict]:
        """Vectorisé — pour le backtester."""
        Xv      = X[self.feature_names].values
        proba   = self.model.predict_proba(Xv)
        classes = list(self.model.classes_)
        idx_l   = classes.index(1)  if  1 in classes else 1
        idx_s   = classes.index(-1) if -1 in classes else 0

        results = []
        for p in proba:
            p_bull, p_bear = float(p[idx_l]), float(p[idx_s])
            direction  = 1 if p_bull >= p_bear else -1
            confidence = max(p_bull, p_bear)
            results.append({
                "predicted_return" : p_bull - p_bear,
                "signal_direction" : direction,
                "signal_magnitude" : (confidence - 0.5) / 0.5,
                "confidence"       : confidence,
                "p_bull"           : p_bull,
                "p_bear"           : p_bear,
            })
        return results

    def passes_threshold(self, pred: dict) -> bool:
        """Filtre de confiance : confidence >= LGBM_CONF_MIN (défaut 0.60 — Master Spec V2)."""
        return pred.get("confidence", 0.0) >= self.conf_min

    # ── persistence ──────────────────────────────────────────────

    def save(self, path: str | None = None):
        path = path or os.path.join(config.MODELS_DIR, "gbr_model.pkl")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        joblib.dump({"model": self.model, "features": self.feature_names}, path)

    def load(self, path: str | None = None):
        path = path or os.path.join(config.MODELS_DIR, "gbr_model.pkl")
        if not os.path.exists(path):
            return self
        data = joblib.load(path)
        self.model         = data["model"]
        self.feature_names = data["features"]
        self.is_fitted     = True
        return self
