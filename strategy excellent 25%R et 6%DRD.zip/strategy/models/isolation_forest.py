"""
IsolationForest-based confidence scoring — detects unusual market regimes.
"""

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
import joblib, os
from strategy import config


class ConfidenceScorer:
    """Scores how 'normal' the current market context is."""

    def __init__(self):
        self.model = IsolationForest(**config.IF_PARAMS)
        self.score_min: float = -0.5
        self.score_max: float = 0.0
        self.is_fitted = False

    def fit(self, X: pd.DataFrame):
        mask = X.notna().all(axis=1)
        X_clean = X.loc[mask]
        self.model.fit(X_clean.values)
        raw = self.model.score_samples(X_clean.values)
        self.score_min = float(np.percentile(raw, 1))
        self.score_max = float(np.percentile(raw, 99))
        self.is_fitted = True
        return self

    def score(self, X: pd.DataFrame) -> float:
        """Return normalised confidence in [0, 1]. Higher = more normal."""
        raw = self.model.score_samples(X.values.reshape(1, -1) if X.ndim == 1 else X.values)
        raw_val = float(raw[-1])
        denom = self.score_max - self.score_min
        if denom == 0:
            denom = 1e-12
        conf = (raw_val - self.score_min) / denom
        return float(np.clip(conf, 0.0, 1.0))

    def passes(self, X: pd.DataFrame) -> tuple[bool, float]:
        s = self.score(X)
        return s >= config.IF_CONFIDENCE_MIN, s

    def batch_passes(self, X: pd.DataFrame) -> pd.Series:
        """Vectorized regime check for massive speedup."""
        #Normalise
        raw = self.model.score_samples(X.values)
        denom = self.score_max - self.score_min
        if denom == 0:
            denom = 1e-12
        conf = (raw - self.score_min) / denom
        norm_scores = np.clip(conf, 0.0, 1.0)
        return pd.Series(norm_scores >= config.IF_CONFIDENCE_MIN, index=X.index)

    def predict_direction(self, X: pd.DataFrame) -> int:
        """IsolationForest is not directional — returns 0 (neutral)."""
        return 0

    # ── persistence ────────────────────────────────────────────

    def save(self, path: str | None = None):
        path = path or os.path.join(config.MODELS_DIR, "isolation_forest.pkl")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        joblib.dump({
            "model": self.model,
            "score_min": self.score_min,
            "score_max": self.score_max,
        }, path)

    def load(self, path: str | None = None):
        path = path or os.path.join(config.MODELS_DIR, "isolation_forest.pkl")
        data = joblib.load(path)
        self.model = data["model"]
        self.score_min = data["score_min"]
        self.score_max = data["score_max"]
        self.is_fitted = True
        return self
