"""
Feature engineering V2 — Master Spec : ICT + MTF H1/H4
No look-ahead except forward target (handled by shifting).
"""

import numpy as np
import pandas as pd
from strategy import config


# ─── Helpers ───────────────────────────────────────────────────

def _ema(series: pd.Series, span: int) -> pd.Series:
    return series.ewm(span=span, adjust=False).mean()


def _rsi(close: pd.Series, period: int) -> pd.Series:
    delta = close.diff()
    gain  = delta.clip(lower=0.0)
    loss  = -delta.clip(upper=0.0)
    avg_gain = gain.ewm(alpha=1.0 / period, min_periods=period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1.0 / period, min_periods=period, adjust=False).mean()
    rs = avg_gain / (avg_loss + 1e-12)
    return 100.0 - 100.0 / (1.0 + rs)


def _macd(close: pd.Series, fast: int, slow: int, signal: int):
    ema_fast   = _ema(close, fast)
    ema_slow   = _ema(close, slow)
    macd_line  = ema_fast - ema_slow
    signal_line = _ema(macd_line, signal)
    hist = macd_line - signal_line
    return macd_line, signal_line, hist


# ─── Main builder ──────────────────────────────────────────────

def build_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Expects df with columns: open, high, low, close, tick_volume, spread, time.
    Returns a DataFrame of features (no look-ahead, all aligned to index).
    """
    close  = df["close"].astype(float)
    high   = df["high"].astype(float)
    low    = df["low"].astype(float)
    open_p = df["open"].astype(float)
    volume = df["tick_volume"].astype(float)

    feats = pd.DataFrame(index=df.index)

    # ── Log returns ──────────────────────────────────────────────
    log_ret = np.log(close / (close.shift(1) + 1e-12))
    for w in config.RETURN_WINDOWS:
        feats[f"ret_{w}"] = log_ret.rolling(w).sum()

    # ── Volatility ───────────────────────────────────────────────
    for w in config.VOLATILITY_WINDOWS:
        feats[f"vol_{w}"] = log_ret.rolling(w).std()
    feats["vol_rel"] = feats["vol_20"] / (feats["vol_20"].rolling(100).mean() + 1e-12)
    feats["skew_20"] = log_ret.rolling(20).skew()
    feats["kurt_20"] = log_ret.rolling(20).kurt()

    # ── Momentum ─────────────────────────────────────────────────
    for w in config.MOMENTUM_WINDOWS:
        feats[f"mom_{w}"] = close.pct_change(w)

    # ── RSI ──────────────────────────────────────────────────────
    for p in config.RSI_PERIODS:
        feats[f"rsi_{p}"] = _rsi(close, p)

    # ── MACD ─────────────────────────────────────────────────────
    fast, slow, sig = config.MACD_PARAMS
    macd_l, macd_s, macd_h = _macd(close, fast, slow, sig)
    feats["macd_line"]   = macd_l
    feats["macd_signal"] = macd_s
    feats["macd_hist"]   = macd_h

    # ── Basic Returns ──────────────────────────────────────────
    feats["logret_1"]   = np.log(close / (open_p + 1e-12))
    feats["log_return"] = np.log(close / (close.shift(1) + 1e-12))

    # ── Bollinger ────────────────────────────────────────────────
    bb_mid  = close.rolling(config.BOLLINGER_PERIOD).mean()
    bb_std  = close.rolling(config.BOLLINGER_PERIOD).std()
    feats["bb_upper"] = bb_mid + config.BOLLINGER_STD * bb_std
    feats["bb_lower"] = bb_mid - config.BOLLINGER_STD * bb_std
    feats["bb_pos"]   = (close - bb_mid) / (bb_std * config.BOLLINGER_STD + 1e-12)
    feats["bb_width"] = (feats["bb_upper"] - feats["bb_lower"]) / (bb_mid + 1e-12)

    # ── ATR ──────────────────────────────────────────────────────
    hl   = high - low
    hc   = (high - close.shift(1)).abs()
    lc   = (low  - close.shift(1)).abs()
    tr   = pd.concat([hl, hc, lc], axis=1).max(axis=1)
    atr  = tr.ewm(span=config.ATR_PERIOD, adjust=False).mean()
    feats["atr_raw"]  = atr
    feats["atr_norm"] = atr / (close + 1e-12)

    # ── Volume ───────────────────────────────────────────────────
    vol_ma = volume.rolling(config.VOLUME_MA_PERIOD).mean()
    feats["vol_ratio"] = volume / (vol_ma + 1e-12)

    # ── Spread ───────────────────────────────────────────────────
    if "spread" in df.columns:
        spread = df["spread"].astype(float)
        feats["spread_ma"] = spread.rolling(config.SPREAD_MA_PERIOD).mean()
    else:
        feats["spread_ma"] = 0.0

    # ── EMA Cross ────────────────────────────────────────────────
    ema_9  = _ema(close, 9)
    ema_21 = _ema(close, 21)
    ema_50 = _ema(close, 50)
    feats["ema_cross_9_21"]  = (ema_9  - ema_21)  / (close + 1e-12)
    feats["ema_cross_21_50"] = (ema_21 - ema_50)  / (close + 1e-12)

    # ── Support / Resistance Distance ────────────────────────────
    lb = config.SR_LOOKBACK
    rolling_high = high.rolling(lb).max()
    rolling_low  = low.rolling(lb).min()
    feats["dist_to_res"] = (rolling_high - close) / (atr + 1e-12)
    feats["dist_to_sup"] = (close - rolling_low)  / (atr + 1e-12)

    # ── OU Mean-Reversion ────────────────────────────────────────
    price_ma_20 = close.rolling(20).mean()
    feats["ou_z_score"] = (close - price_ma_20) / (close.rolling(20).std() + 1e-12)
    feats["ou_theta"]   = pd.Series(float(0.5 / (20 * 5 * 60)), index=df.index)

    # ── Candle metrics ───────────────────────────────────────────
    body    = (close - open_p).abs()
    c_range = (high - low) + 1e-12
    feats["body_ratio"] = body / c_range
    feats["body_dir"]   = np.sign(close - open_p)

    lower_wick = close.clip(upper=open_p) - low
    upper_wick = high - close.clip(lower=open_p)

    # ── Session ────────────────────────────────────────────
    # Support DatetimeIndex (quand time est l'index) ET colonne 'time'
    _has_dt_index = isinstance(df.index, pd.DatetimeIndex)
    if _has_dt_index:
        # Index = DatetimeIndex : accès direct via .hour
        _idx = df.index
        hour   = pd.Series(_idx.hour,   index=df.index)
        minute = pd.Series(_idx.minute, index=df.index)
    elif "time" in df.columns:
        # Colonne 'time' : passer par .dt
        _ts    = pd.to_datetime(df["time"])
        hour   = _ts.dt.hour
        minute = _ts.dt.minute
    else:
        hour   = pd.Series(12, index=df.index)
        minute = pd.Series(0,  index=df.index)

    feats["is_london"]  = ((7  <= hour) & (hour < 17)).astype(float)
    feats["is_newyork"] = ((13 <= hour) & (hour < 22)).astype(float)
    hour_f = hour + minute / 60.0

    # ── Macro / Regime ───────────────────────────────────────────
    vol_recent = feats["vol_20"]
    vol_95     = vol_recent.rolling(500).quantile(0.95)
    feats["macro_surprise"] = (vol_recent / (vol_95 + 1e-12)).clip(upper=3.0)
    feats["macro_decay"]    = feats["macro_surprise"].ewm(halflife=12).mean()

    # ── VWAP ─────────────────────────────────────────────────────
    typical_price = (high + low + close) / 3.0
    vol_sum       = volume.rolling(20).sum() + 1e-12
    vwap          = (typical_price * volume).rolling(20).sum() / vol_sum
    feats["vwap_dist"] = (close - vwap) / (atr + 1e-12)

    # ── Vol Regime ───────────────────────────────────────────────
    atr_pct = atr.rolling(500).rank(pct=True)
    feats["vol_regime"]    = atr_pct
    feats["vol_regime_ok"] = ((atr_pct >= 0.20) & (atr_pct <= 0.80)).astype(float)

    # ════════════════════════════════════════════════════════════
    # ── ICT BLOC 1 : Liquidity Sweep ────────────────────────────
    swing_h = high.rolling(10).max().shift(1)
    swing_l = low.rolling(10).min().shift(1)
    feats["sweep_bull"] = ((low < swing_l) & (close > swing_l)).astype(float)
    feats["sweep_bear"] = ((high > swing_h) & (close < swing_h)).astype(float)

    # ── ICT BLOC 2 : Fair Value Gap ─────────────────────────────
    feats["fvg_bull"] = (df["low"].shift(-1)  > high.shift(1)).astype(float)
    feats["fvg_bear"] = (df["high"].shift(-1) < low.shift(1) ).astype(float)
    feats["fvg_size"] = (df["low"].shift(-1)  - high.shift(1)).abs() / (atr + 1e-12)

    # ── ICT BLOC 3 : Premium / Discount ─────────────────────────
    r_high = high.rolling(50).max()
    r_low  = low.rolling(50).min()
    equil  = (r_high + r_low) / 2.0
    feats["pd_zone"]     = (close - equil) / (r_high - r_low + 1e-12)
    feats["in_discount"] = (feats["pd_zone"] < -0.30).astype(float)
    feats["in_premium"]  = (feats["pd_zone"] >  0.30).astype(float)

    # ── ICT BLOC 4 : Kill Zones ──────────────────────────────────
    feats["kz_london"]    = ((7.0  <= hour_f) & (hour_f < 9.0 )).astype(float)
    feats["kz_ny"]        = ((13.0 <= hour_f) & (hour_f < 15.0)).astype(float)
    feats["kz_lnd_close"] = ((15.0 <= hour_f) & (hour_f < 16.0)).astype(float)
    feats["in_killzone"]  = (
        feats["kz_london"].astype(bool) |
        feats["kz_ny"].astype(bool)     |
        feats["kz_lnd_close"].astype(bool)
    ).astype(float)
    # Alias pour compatibilité ancienne version
    feats["kz_overlap"] = feats["kz_lnd_close"]

    # ── ICT BLOC 5 : OTE — Fibonacci 61.8–78.6% ─────────────────
    rng = r_high - r_low + 1e-12
    feats["ote_bull"] = ((close >= r_high - 0.786*rng) & (close <= r_high - 0.618*rng)).astype(float)
    feats["ote_bear"] = ((close >= r_low  + 0.618*rng) & (close <= r_low  + 0.786*rng)).astype(float)

    # ── ICT BLOC 6 : Stop Hunt Précis (1–5 pips) ────────────────
    pip = 0.0001
    feats["stop_hunt_bull"] = (
        ((swing_l - low).clip(0) > 0) &
        ((swing_l - low).clip(0) < 5*pip) &
        (close > swing_l)
    ).astype(float)
    feats["stop_hunt_bear"] = (
        ((high - swing_h).clip(0) > 0) &
        ((high - swing_h).clip(0) < 5*pip) &
        (close < swing_h)
    ).astype(float)

    # ── ICT BLOC 7 : Displacement ────────────────────────────────
    feats["displacement"] = ((close - close.shift(1)).abs() > 1.5*atr).astype(float)
    feats["disp_dir"]     = np.sign(close - close.shift(1))

    # ── ICT BLOC 8 : Rejection Candle ────────────────────────────
    feats["rejection_bull"] = (
        (lower_wick > 2*body) &
        (lower_wick > 0.5*c_range) &
        (close > open_p)
    ).astype(float)
    feats["rejection_bear"] = (
        (upper_wick > 2*body) &
        (upper_wick > 0.5*c_range) &
        (close < open_p)
    ).astype(float)

    # ════════════════════════════════════════════════════════════
    # ── MTF BLOC : H1 (12 barres M5) ────────────────────────────
    h1_ema20 = close.ewm(span=12*20, adjust=False).mean()
    h1_ema50 = close.ewm(span=12*50, adjust=False).mean()
    feats["h1_bias"]     = np.sign(h1_ema20 - h1_ema50)
    feats["h1_strength"] = (h1_ema20 - h1_ema50) / (close + 1e-12)

    h1_high_roll = high.rolling(12).max()
    h1_low_roll  = low.rolling(12).min()
    feats["h1_hh"] = (h1_high_roll > h1_high_roll.shift(12)).astype(float)
    feats["h1_hl"] = (h1_low_roll  > h1_low_roll.shift(12)).astype(float)
    feats["h1_bullish_structure"] = (feats["h1_hh"].astype(bool) & feats["h1_hl"].astype(bool)).astype(float)
    feats["h1_bearish_structure"] = ((~feats["h1_hh"].astype(bool)) & (~feats["h1_hl"].astype(bool))).astype(float)

    h1_move    = (close - close.shift(12)).abs()
    h1_impulse = h1_move > 2.0 * atr * np.sqrt(12)
    feats["h1_ob_bull"] = (h1_impulse & (close > close.shift(12))).astype(float)
    feats["h1_ob_bear"] = (h1_impulse & (close < close.shift(12))).astype(float)
    feats["h1_fvg_bull"] = (low.shift(-12) > high.shift(12)).astype(float)
    feats["h1_fvg_bear"] = (high.shift(-12) < low.shift(12)).astype(float)

    # ── MTF BLOC : H4 (48 barres M5) ────────────────────────────
    h4_ema20 = close.ewm(span=48*20, adjust=False).mean()
    h4_ema50 = close.ewm(span=48*50, adjust=False).mean()
    feats["h4_bias"]     = np.sign(h4_ema20 - h4_ema50)
    feats["h4_strength"] = (h4_ema20 - h4_ema50) / (close + 1e-12)

    h4_high = high.rolling(48).max()
    h4_low  = low.rolling(48).min()
    h4_eq   = (h4_high + h4_low) / 2.0
    feats["h4_pd_zone"]     = (close - h4_eq) / (h4_high - h4_low + 1e-12)
    feats["h4_in_discount"] = (feats["h4_pd_zone"] < -0.25).astype(float)
    feats["h4_in_premium"]  = (feats["h4_pd_zone"] >  0.25).astype(float)

    # ── MTF BLOC : Alignement M5 + H1 + H4 ─────────────────────
    m5_dir = np.sign(close - close.shift(3))
    feats["mtf_bull"] = (
        (feats["h4_bias"] == 1) &
        (feats["h1_bias"] == 1) &
        (m5_dir == 1)
    ).astype(float)
    feats["mtf_bear"] = (
        (feats["h4_bias"] == -1) &
        (feats["h1_bias"] == -1) &
        (m5_dir == -1)
    ).astype(float)
    feats["h4h1_bull"] = ((feats["h4_bias"] ==  1) & (feats["h1_bias"] ==  1)).astype(float)
    feats["h4h1_bear"] = ((feats["h4_bias"] == -1) & (feats["h1_bias"] == -1)).astype(float)

    feats["kz_mtf_bull"] = (feats["in_killzone"].astype(bool) & feats["mtf_bull"].astype(bool)).astype(float)
    feats["kz_mtf_bear"] = (feats["in_killzone"].astype(bool) & feats["mtf_bear"].astype(bool)).astype(float)

    return feats


# ─── Target variable — Master Spec V2 ─────────────────────────

def build_target(df: pd.DataFrame) -> pd.Series:
    """
    Classification target avec seuil dynamique adapté RR=1.5.
    FORWARD_PERIOD=3 barres (15 min) — optimal pour TP 1.5×ATR.
    Seuil = 0.4× volatilité — plus sensible, plus de trades labellisés.
    Retourne : +1 (Long), -1 (Short), 0 (Neutre — exclu de l'entraînement).
    """
    close     = df["close"].astype(float)
    log_close = np.log(close + 1e-12)
    fp        = getattr(config, "FORWARD_PERIOD", 3)

    y_return  = log_close.shift(-fp) - log_close

    # Seuil 0.4× — plus permissif que 0.5× → plus de barres labellisées
    threshold = log_close.diff(1).rolling(20).std() * 0.4
    threshold = threshold.fillna(log_close.diff(1).std() * 0.4)

    y = pd.Series(0, index=df.index, name="target", dtype=float)
    y[y_return >  threshold] =  1.0
    y[y_return < -threshold] = -1.0

    y.iloc[-fp:] = np.nan
    return y


# Alias
build_target_classification = build_target


# ─── Feature subsets ──────────────────────────────────────────

REGIME_FEATURES = [
    "vol_20", "vol_rel", "spread_ma",
    "skew_20", "kurt_20",
    "atr_norm",
]

def get_regime_features(feats: pd.DataFrame) -> pd.DataFrame:
    cols = [c for c in REGIME_FEATURES if c in feats.columns]
    return feats[cols]

def get_prediction_features(feats: pd.DataFrame) -> pd.DataFrame:
    """Toutes les features sauf atr_raw (usage interne uniquement)."""
    exclude = {"atr_raw"}
    cols = [c for c in feats.columns if c not in exclude]
    return feats[cols]
