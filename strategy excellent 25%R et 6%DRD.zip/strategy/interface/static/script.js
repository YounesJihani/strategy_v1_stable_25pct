document.addEventListener('DOMContentLoaded', () => {
    const runBtn = document.getElementById('run-btn');
    const marketSelect = document.getElementById('market');
    const tfSelect = document.getElementById('timeframe');
    const monthsInput = document.getElementById('months');
    const monthsVal = document.getElementById('months-val');

    const loader = document.getElementById('loader');
    const chartImg = document.getElementById('equity-chart');
    const placeholder = document.getElementById('placeholder-msg');

    const pfVal = document.getElementById('pf-val');
    const wrVal = document.getElementById('wr-val');
    const pnlVal = document.getElementById('pnl-val');
    const ddVal = document.getElementById('dd-val');
    const symbolTitle = document.getElementById('current-symbol');
    const tradesBody = document.getElementById('trades-body');

    // Update months label
    monthsInput.addEventListener('input', () => {
        monthsVal.innerText = `${monthsInput.value} Mois`;
    });

    // Fetch symbols
    async function fetchSymbols() {
        try {
            const res = await fetch('/api/symbols');
            const symbols = await res.json();
            marketSelect.innerHTML = symbols.map(s => `<option value="${s}">${s}</option>`).join('');
        } catch (e) {
            console.error("Failed to fetch symbols", e);
        }
    }

    fetchSymbols();

    runBtn.addEventListener('click', async () => {
        // Prepare UI
        loader.classList.remove('hidden');
        chartImg.classList.add('hidden');
        placeholder.classList.add('hidden');
        runBtn.disabled = true;
        runBtn.innerText = "IA EN ACTION...";

        const payload = {
            symbol: marketSelect.value,
            timeframe: tfSelect.value,
            months: parseInt(monthsInput.value)
        };

        symbolTitle.innerText = payload.symbol;

        try {
            const response = await fetch('/api/run_backtest', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (!response.ok) throw new Error("Backtest failed");

            const data = await response.json();

            // Update Stats
            pfVal.innerText = data.profit_factor.toFixed(2);
            wrVal.innerText = `${data.win_rate.toFixed(1)}%`;
            pnlVal.innerText = `$${data.total_pnl.toFixed(2)}`;
            ddVal.innerText = `${data.max_drawdown.toFixed(2)}%`;

            // Update Chart
            chartImg.src = `data:image/png;base64,${data.plot}`;
            chartImg.classList.remove('hidden');

            // Update Trades
            if (data.trades && data.trades.length > 0) {
                tradesBody.innerHTML = data.trades.reverse().map(t => `
                    <tr>
                        <td style="color: ${t.direction === 1 ? '#00ff87' : '#ff416c'}">${t.direction === 1 ? 'BUY' : 'SELL'}</td>
                        <td style="color: ${t.pnl >= 0 ? '#00ff87' : '#ff416c'}">${t.pnl.toFixed(2)}</td>
                        <td>${(t.return * 100).toFixed(2)}%</td>
                        <td>${t.duration}</td>
                    </tr>
                `).join('');
            } else {
                tradesBody.innerHTML = '<tr><td colspan="4" class="empty-msg">Aucun trade généré</td></tr>';
            }

        } catch (error) {
            alert("Erreur lors du backtest : " + error.message);
        } finally {
            loader.classList.add('hidden');
            runBtn.disabled = false;
            runBtn.innerText = "LANCER L'ANALYSE";
        }
    });
});
