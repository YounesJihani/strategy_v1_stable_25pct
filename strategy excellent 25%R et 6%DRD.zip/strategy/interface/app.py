import sys, os, datetime, base64, io
import pandas as pd
import numpy as np
import MetaTrader5 as mt5
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import matplotlib.pyplot as plt
import seaborn as sns

# Fix path to import shared logic
root_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, root_dir)

from strategy import config
from strategy.execution.order_manager import init_mt5, shutdown_mt5
from strategy.backtest.tick_backtester import BarBacktester

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class BacktestRequest(BaseModel):
    symbol: str
    timeframe: str = "M5"
    months: int = 6

def get_symbol_data(symbol, tf_name, months):
    tf_map = {
        "M1": mt5.TIMEFRAME_M1,
        "M5": mt5.TIMEFRAME_M5,
        "M15": mt5.TIMEFRAME_M15,
        "H1": mt5.TIMEFRAME_H1,
    }
    tf = tf_map.get(tf_name, mt5.TIMEFRAME_M5)
    
    # Approx bars
    bars_per_month = 22 * 16 * 12 # for M5
    if tf_name == "H1": bars_per_month = 22 * 24
    if tf_name == "M1": bars_per_month = 22 * 16 * 60
    
    target_bars = months * bars_per_month
    chunk = 5000
    all_dfs = []
    offset = 0
    
    while offset < target_bars:
        n = min(chunk, target_bars - offset)
        rates = mt5.copy_rates_from_pos(symbol, tf, offset, n)
        if rates is None or len(rates) == 0: break
        all_dfs.append(pd.DataFrame(rates))
        offset += len(rates)
        if len(rates) < n: break
        
    if not all_dfs: return pd.DataFrame()
    df = pd.concat(all_dfs).drop_duplicates('time').sort_values('time')
    df['time'] = pd.to_datetime(df['time'], unit='s')
    return df

@app.get("/api/symbols")
def list_symbols():
    if not init_mt5():
        raise HTTPException(status_code=500, detail="MT5 connection failed")
    
    # Obtenir tous les symboles disponibles sur le serveur
    symbols = mt5.symbols_get()
    if not symbols:
        return ["EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "AMD", "NVDA"]
    
    # Filtrer pour garder les symboles majeurs et ceux déjà actifs
    # On trie pour mettre les Forex en premier
    result = [s.name for s in symbols if s.visible or s.select or len(s.name) <= 6 or s.name in ["Gold", "AMD", "NVDA", "SP500m"]]
    return sorted(list(set(result)))

@app.post("/api/run_backtest")
async def run_backtest(req: BacktestRequest):
    if not init_mt5():
        raise HTTPException(status_code=500, detail="MT5 connection failed")
    
    # S'assurer que le symbole est sélectionné dans MT5
    if not mt5.symbol_select(req.symbol, True):
         print(f"Warning: Could not select {req.symbol}")

    config.MT5_SYMBOL = req.symbol
    config.MT5_TIMEFRAME_NAME = req.timeframe
    
    df = get_symbol_data(req.symbol, req.timeframe, req.months)
    if df.empty:
        raise HTTPException(status_code=404, detail="No data found for this symbol")
    
    backtester = BarBacktester(initial_capital=10000.0)
    # Train and test
    results = backtester.run(df, verbose=False)
    
    # Process results for JSON
    test_metrics = results['test_metrics']
    trades = results['trades']
    equity = results['equity_curve']
    
    # Generate Plot
    plt.figure(figsize=(10, 5))
    plt.style.use('dark_background')
    plt.plot(equity, color='#00f2fe', linewidth=2)
    plt.title(f"Performance: {req.symbol} ({req.timeframe})")
    plt.grid(True, alpha=0.2)
    
    buf = io.BytesIO()
    plt.savefig(buf, format='png', transparent=True)
    buf.seek(0)
    plot_base64 = base64.b64encode(buf.read()).decode('utf-8')
    plt.close()

    # Summary
    summary = {
        "profit_factor": test_metrics.get('profit_factor', 0),
        "win_rate": test_metrics.get('win_rate', 0) * 100,
        "total_pnl": test_metrics.get('total_pnl', 0),
        "max_drawdown": test_metrics.get('max_drawdown', 0) * 100,
        "sharpe": test_metrics.get('sharpe', 0),
        "n_trades": len(trades),
        "plot": plot_base64,
        "trades": trades[-20:] # Last 20 trades
    }
    
    return summary

from fastapi.responses import FileResponse

# Serve static files
app.mount("/static", StaticFiles(directory=os.path.join(os.path.dirname(__file__), "static")), name="static")

@app.get("/")
async def read_index():
    return FileResponse(os.path.join(os.path.dirname(__file__), "static", "index.html"))

@app.get("/{file_name}")
async def serve_file(file_name: str):
    file_path = os.path.join(os.path.dirname(__file__), "static", file_name)
    if os.path.exists(file_path):
        return FileResponse(file_path)
    raise HTTPException(status_code=404)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
