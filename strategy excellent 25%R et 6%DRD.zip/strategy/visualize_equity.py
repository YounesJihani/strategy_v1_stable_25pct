"""
visualize_equity.py
───────────────────
Génère un graphe premium de l'évolution du capital sur les données de test.
Lit : equity_curve.csv  (colonnes : date, equity  — ou time, capital)
Sortie : equity_curve_chart.png
"""

import sys, os
import pandas as pd
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.ticker import FuncFormatter
from matplotlib.gridspec import GridSpec

matplotlib.rcParams["font.family"] = "DejaVu Sans"

ROOT = os.path.dirname(os.path.abspath(__file__))
CSV_CANDIDATES = [
    os.path.join(ROOT, "equity_curve.csv"),
    os.path.join(ROOT, "backtest", "equity_curve.csv"),
    os.path.join(ROOT, "..", "equity_curve.csv"),
]

# ── Charge le CSV ───────────────────────────────────────────────
df = None
csv_path_found = None
for path in CSV_CANDIDATES:
    if os.path.exists(path):
        csv_path_found = path
        break

if csv_path_found is None:
    sys.exit("[ERREUR] equity_curve.csv introuvable. Lancez d'abord train_and_backtest.py")

# Lecture flexible (avec ou sans header)
raw = pd.read_csv(csv_path_found, header=None)
print(f"[OK] Fichier : {csv_path_found}  |  {raw.shape[0]} lignes, {raw.shape[1]} colonnes")

# Cas 1 : toutes les colonnes sont numériques → pas de header
if pd.to_numeric(raw.iloc[0, 0], errors="coerce") is not np.nan and \
   not str(raw.iloc[0, 0]).replace(".", "").replace("-", "").isdigit() is False:
    try:
        pd.to_numeric(raw.iloc[0, 0])
        raw.columns = [f"col{i}" for i in range(raw.shape[1])]
        first_col = raw["col0"]
        equity_numeric = pd.to_numeric(first_col, errors="coerce")
        if equity_numeric.notna().sum() < 5:
            # Header présent → re-lire correctement
            raw = pd.read_csv(csv_path_found)
        else:
            raw = pd.DataFrame({"equity": equity_numeric})
    except (ValueError, TypeError):
        raw = pd.read_csv(csv_path_found)

df = raw.copy()
df.columns = [str(c).strip().lower() for c in df.columns]

# Colonne date
date_col = next((c for c in df.columns if c in ("date","time","timestamp","datetime","index")), None)
if date_col:
    try:
        df["date"] = pd.to_datetime(df[date_col])
    except Exception:
        df["date"] = pd.RangeIndex(len(df))
else:
    df["date"] = pd.RangeIndex(len(df))

# Colonne capital
equity_col = next((c for c in df.columns if c in ("equity","capital","balance","value","0","col0")), None)
if equity_col:
    df["equity"] = pd.to_numeric(df[equity_col], errors="coerce")
else:
    # Prend la première colonne numérique disponible
    for c in df.columns:
        ser = pd.to_numeric(df[c], errors="coerce")
        if ser.notna().sum() > 5:
            df["equity"] = ser
            print(f"[Info] Colonne capital auto-détectée : '{c}'")
            break
    else:
        sys.exit("[ERREUR] Impossible de trouver une colonne de capital numérique.")

df = df.dropna(subset=["equity"]).sort_values("date").reset_index(drop=True)
print(f"[Info] {len(df)} points de données | "
      f"{df['date'].iloc[0]} → {df['date'].iloc[-1]}")

# ── Métriques ───────────────────────────────────────────────────
initial   = df["equity"].iloc[0]
final     = df["equity"].iloc[-1]
total_ret = (final - initial) / initial * 100
peak      = df["equity"].cummax()
drawdown  = (df["equity"] - peak) / peak * 100          # en %
max_dd    = drawdown.min()
roll_ret  = df["equity"].pct_change().dropna()
sharpe    = (roll_ret.mean() / (roll_ret.std() + 1e-12)) * np.sqrt(252 * 24 * 12)

# Meilleure et pire séquence
wins  = roll_ret[roll_ret > 0]
loses = roll_ret[roll_ret < 0]
win_rate = len(wins) / (len(wins) + len(loses)) * 100 if (len(wins)+len(loses)) > 0 else 0

# ── Design : palette dark premium ────────────────────────────────
BG      = "#0d1117"
PANEL   = "#161b22"
GREEN   = "#39d353"
RED     = "#f85149"
GOLD    = "#ffd60a"
BLUE    = "#58a6ff"
GRAY    = "#8b949e"
WHITE   = "#e6edf3"

fig = plt.figure(figsize=(16, 9), facecolor=BG)
gs  = GridSpec(3, 4, figure=fig, hspace=0.08, wspace=0.3,
               left=0.05, right=0.96, top=0.90, bottom=0.08)

ax_eq  = fig.add_subplot(gs[0:2, 0:4])   # courbe principale  (2/3 hauteur)
ax_dd  = fig.add_subplot(gs[2, 0:4], sharex=ax_eq)  # drawdown

# ── Courbe de capital ────────────────────────────────────────────
color_line = GREEN if total_ret >= 0 else RED

ax_eq.set_facecolor(BG)
ax_eq.fill_between(df["date"], initial, df["equity"],
                   where=df["equity"] >= initial,
                   color=GREEN, alpha=0.15, interpolate=True)
ax_eq.fill_between(df["date"], initial, df["equity"],
                   where=df["equity"] < initial,
                   color=RED, alpha=0.15, interpolate=True)
ax_eq.plot(df["date"], df["equity"], color=color_line, linewidth=1.5, zorder=5)
ax_eq.axhline(initial, color=GRAY, linewidth=0.8, linestyle="--", alpha=0.6)

# Peak marker
peak_idx = df["equity"].idxmax()
ax_eq.annotate(f"  Pic: {df['equity'].iloc[peak_idx]:,.0f}",
               xy=(df["date"].iloc[peak_idx], df["equity"].iloc[peak_idx]),
               fontsize=8, color=GOLD, fontweight="bold",
               arrowprops=dict(arrowstyle="-", color=GOLD, lw=0.8))

# Style
ax_eq.set_ylabel("Capital ($)", color=GRAY, fontsize=10)
ax_eq.tick_params(colors=GRAY, labelsize=9)
ax_eq.yaxis.set_major_formatter(FuncFormatter(lambda x, _: f"${x:,.0f}"))
ax_eq.spines[:].set_color(PANEL)
ax_eq.grid(axis="y", color=PANEL, linewidth=0.8)
ax_eq.set_xlim(df["date"].iloc[0], df["date"].iloc[-1])
plt.setp(ax_eq.get_xticklabels(), visible=False)

# ── Drawdown ─────────────────────────────────────────────────────
ax_dd.set_facecolor(BG)
ax_dd.fill_between(df["date"], 0, drawdown, color=RED, alpha=0.5)
ax_dd.plot(df["date"], drawdown, color=RED, linewidth=0.8)
ax_dd.set_ylabel("Drawdown (%)", color=GRAY, fontsize=9)
ax_dd.tick_params(colors=GRAY, labelsize=8)
ax_dd.yaxis.set_major_formatter(FuncFormatter(lambda x, _: f"{x:.1f}%"))
ax_dd.spines[:].set_color(PANEL)
ax_dd.grid(axis="y", color=PANEL, linewidth=0.8)
ax_dd.tick_params(axis="x", labelrotation=30, labelsize=8)

# ── Titre ────────────────────────────────────────────────────────
sign = "+" if total_ret >= 0 else ""
fig.suptitle(
    f"Courbe de Capital — Données de Test  |  "
    f"{sign}{total_ret:.2f}%  |  DD max: {max_dd:.2f}%",
    color=WHITE, fontsize=14, fontweight="bold", y=0.95
)

# ── Panneau de stats (bas-droite) ─────────────────────────────────
stats = [
    ("Capital initial",  f"${initial:,.0f}"),
    ("Capital final",    f"${final:,.0f}"),
    ("Rendement total",  f"{sign}{total_ret:.2f}%"),
    ("Max Drawdown",     f"{max_dd:.2f}%"),
    ("Sharpe (approx)", f"{sharpe:.2f}"),
    ("Win rate bars",    f"{win_rate:.1f}%"),
    ("Nb. points",       f"{len(df):,}"),
]

y0 = 0.165
for label, val in stats:
    col = GREEN if ("+" in val or (not ("-" in val) and "%" in val and val.replace("%","").replace(".","").replace(",","").lstrip("+").lstrip("-").isdigit())) else WHITE
    if "Drawdown" in label or val.startswith("-"):
        col = RED
    fig.text(0.012, y0, label + ":", color=GRAY,  fontsize=8, ha="left", va="center")
    fig.text(0.175, y0, val,         color=col,   fontsize=8, ha="left", va="center", fontweight="bold")
    y0 -= 0.022

# ── Sauvegarde ───────────────────────────────────────────────────
OUT = os.path.join(ROOT, "equity_curve_chart.png")
fig.savefig(OUT, dpi=150, bbox_inches="tight", facecolor=BG)
print(f"[OK] Graphe sauvegardé : {OUT}")
plt.show()
