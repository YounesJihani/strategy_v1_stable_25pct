
import pandas as pd
import numpy as np
import MetaTrader5 as mt5
from strategy.models.feature_engineering import build_features, build_target
from strategy.models.gradient_boosting import ReturnPredictor
from strategy.risk.stop_calculator import calculate_rr15_stops
from strategy import config

def analyze_one_trade():
    mt5.initialize()
    rates = mt5.copy_rates_from_pos("EURUSD", mt5.TIMEFRAME_M5, 0, 10000)
    df = pd.DataFrame(rates)
    df["time"] = pd.to_datetime(df["time"], unit="s")
    
    feats = build_features(df)
    target = build_target(df)
    
    # Simuler une entrée
    i = 5000
    price = df.iloc[i]["close"]
    atr = feats.iloc[i]["atr_raw"]
    direction = 1 # Long pour test
    
    # Sizing à 1.5%
    capital = 10000
    risk_pct = 0.015
    
    ctx_df = df.iloc[i-10:i+1]
    ctx_feats = feats.iloc[i-10:i+1]
    
    sl, tp, pos_size, trail = calculate_rr15_stops(price, direction, atr, capital, capital*0.015, ctx_df, ctx_feats)
    
    print(f"Entry: {price:.5f}, SL: {sl:.5f}, TP: {tp:.5f}")
    print(f"SL Dist: {abs(price-sl)*10000:.1f} pips, TP Dist: {abs(tp-price)*10000:.1f} pips")
    
    # Suivre les barres suivantes
    for j in range(i+1, i+100):
        row = df.iloc[j]
        h, l = row["high"], row["low"]
        
        hit_sl = l <= sl
        hit_tp = h >= tp
        
        if hit_sl and hit_tp:
            print(f"Bar {j}: BOTH HIT! Priority SL.")
            break
        if hit_sl:
            print(f"Bar {j}: SL HIT. Loss.")
            break
        if hit_tp:
            print(f"Bar {j}: TP HIT. Win.")
            break
    else:
        print("Trade timed out.")

analyze_one_trade()
