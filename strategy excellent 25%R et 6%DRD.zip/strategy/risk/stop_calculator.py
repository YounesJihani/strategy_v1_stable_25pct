"""
Stop Calculator V2 — Master Spec RR=1.5
SL chirurgical (Stop Hunt level + ATR) + TP = exactement 1.5×SL_dist.
Trailing stop activé à 80% du TP (0.3×ATR trail).
"""
import pandas as pd
from strategy import config


def calculate_stops(
    entry_price: float,
    predicted_return: float,
    atr: float,
    capital: float,
    position_size: float,
    direction: int,
) -> tuple[float, float, float]:
    """
    Legacy interface — délègue vers calculate_rr15_stops sans df/feats.
    Utilisé par le backtester simple.
    """
    sl_dist = config.SL_ATR_MULT * atr       # 1.2×ATR par défaut
    sl_dist = max(sl_dist, 1e-6)

    # Cap position size au risque maximum
    risk_currency     = position_size * sl_dist
    max_risk_currency = capital * config.MAX_RISK_PER_TRADE
    if risk_currency > max_risk_currency:
        position_size = max_risk_currency / sl_dist

    tp_dist = config.MIN_RR_RATIO * sl_dist   # 1.5×SL_dist

    if direction == 1:
        sl = entry_price - sl_dist
        tp = entry_price + tp_dist
    else:
        sl = entry_price + sl_dist
        tp = entry_price - tp_dist

    return sl, tp, position_size


def calculate_rr15_stops(
    entry: float,
    direction: int,
    atr: float,
    capital: float,
    pos_size: float,
    df: pd.DataFrame,
    feats: pd.DataFrame,
) -> tuple[float, float, float, float]:
    """
    Stop chirurgical RR=1.5 — Master Spec V2.
    - SL : min(stop_hunt_level, ATR×1.2) → le plus proche
    - TP : exactement 1.5× la distance SL
    - Trail activation : 80% du TP atteint (SL suit à 0.3×ATR)

    Returns: (sl, tp, pos_size_adjusted, trail_activation_ratio)
    """
    pip = 0.0001

    if direction == 1:  # Long
        hunt_low   = df["low"].rolling(5).min().iloc[-1] if len(df) >= 5 else entry - atr
        sl_hunt    = float(hunt_low) - 2 * pip
        sl_atr     = entry - config.SL_ATR_MULT * atr
        sl         = max(sl_hunt, sl_atr)         # Le moins risqué (plus proche de l'entrée)
        sl_dist    = abs(entry - sl)
        tp         = entry + config.MIN_RR_RATIO * sl_dist
    else:               # Short
        hunt_high  = df["high"].rolling(5).max().iloc[-1] if len(df) >= 5 else entry + atr
        sl_hunt    = float(hunt_high) + 2 * pip
        sl_atr     = entry + config.SL_ATR_MULT * atr
        sl         = min(sl_hunt, sl_atr)         # Le moins risqué
        sl_dist    = abs(sl - entry)
        tp         = entry - config.MIN_RR_RATIO * sl_dist

    # Calcul de la distance de risque
    risk_dist = abs(entry - sl)
    if risk_dist < 1e-12:
        return sl, tp, 0.0, 0.0

    # pos_size est maintenant la fraction de risque (ex: 0.015)
    # On veut : volume * (risk_dist / entry) = capital * pos_size
    # volume = (capital * pos_size) / (risk_dist / entry)
    
    # Cap du risque à la config
    risk_fraction = min(pos_size, config.MAX_RISK_PER_TRADE)
    risk_amount = capital * risk_fraction
    
    # Volume notionnel (ex: 100,000$ pour 1 lot EURUSD)
    volume = risk_amount / (risk_dist / entry)
    
    # On peut aussi limiter le levier global ici si nécessaire
    
    trail_activation = 0.80   # Trailing actif à 80% du TP

    return sl, tp, volume, trail_activation
