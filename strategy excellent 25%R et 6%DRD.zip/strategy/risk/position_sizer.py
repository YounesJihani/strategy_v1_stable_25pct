"""
Position sizing via Quarter-Kelly formula.
BUG 3 FIX: Kelly metrics now updatable in rolling fashion from live trades.
BUG 4 FIX: signal_magnitude now modulates position size.
"""
from strategy import config


def quarter_kelly_size(
    win_rate: float,
    avg_win: float,
    avg_loss: float,
    capital: float,
    z_score: float = 0.0,
    signal_magnitude: float = 1.0,   # BUG 4 FIX: magnitude of conviction
) -> float:
    """
    Kelly fraction = (p*b - q) / b  with b = avg_win / avg_loss.
    Returns position size in account currency.

    signal_magnitude : GBR predicted return normalized to [0,1].
                       Modulates final position size (BUG 4 FIX).
    z_score          : OU Z-Score — activates Hunting Mode if extreme.
    """
    if avg_loss == 0 or capital <= 0:
        return 0.0

    b = avg_win / (avg_loss + 1e-12)
    p = win_rate
    q = 1.0 - p

    kelly = (p * b - q) / (b + 1e-12)
    qk = kelly / config.KELLY_DIVISOR

    # ── Hunting Mode Multiplier (z_score >= HUNT_ZSCORE_MIN) ──────
    multiplier = 1.0
    if abs(z_score) >= config.HUNT_ZSCORE_MIN:
        multiplier = 2.0   # Double size for extreme conviction

    # ── Safety caps ───────────────────────────────────────────────
    qk = max(qk, 0.001)                      # minimum 0.1% risk
    max_risk = 0.015 * multiplier            # 1.5% normal / 3% hunt mode
    qk = min(qk, max_risk)

    # ── Signal Magnitude modulation (BUG 4 FIX) ───────────────────
    # signal_magnitude in [0, 1]: scale down on low-conviction signals
    mag = float(max(0.25, min(1.0, signal_magnitude)))  # floor at 25%
    qk *= mag

    return qk


def update_kelly_stats(
    trades: list,
    window: int = 50,
) -> tuple[float, float, float]:
    """
    BUG 3 FIX: Compute rolling Kelly parameters from the last N live trades.
    Returns (win_rate, avg_win, avg_loss) for dynamic sizing.
    """
    if not trades:
        return 0.52, 0.001, 0.001   # conservative defaults

    recent = trades[-window:]
    rets = [t["return"] for t in recent]
    wins  = [r for r in rets if r > 0]
    losses = [abs(r) for r in rets if r <= 0]

    win_rate = len(wins) / (len(recent) + 1e-12)
    avg_win  = float(sum(wins)  / (len(wins)   + 1e-12))
    avg_loss = float(sum(losses) / (len(losses) + 1e-12))

    # Safety floors
    win_rate = max(0.3, min(0.9, win_rate))
    avg_win  = max(1e-5, avg_win)
    avg_loss = max(1e-5, avg_loss)

    return win_rate, avg_win, avg_loss
