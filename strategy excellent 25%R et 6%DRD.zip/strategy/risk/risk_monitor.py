"""
Real-time risk monitor — tracks daily/monthly P&L and drawdown.
State is persisted to disk to survive restarts.
"""

import json, os, time
from datetime import datetime, timezone
from strategy import config


class RiskMonitor:
    """Tracks cumulative risk metrics and halts trading when limits are hit."""

    def __init__(self, initial_capital: float):
        self.initial_capital = initial_capital
        self.capital = initial_capital
        self.peak = initial_capital
        self.daily_pnl = 0.0
        self.monthly_pnl = 0.0
        self.trades_today = 0
        self.last_trade_ts = 0.0
        self.current_day = ""
        self.current_month = ""
        self.halted         = False
        self.halt_reason    = ""
        self.kelly_multiplier = 1.0   # ACTION 6 : réduit progressivement en DD
        self.live_trades: list = []   # pour Kelly dynamique
        self._sync_date()

    def _sync_date(self):
        now = datetime.now(timezone.utc)
        day_str = now.strftime("%Y-%m-%d")
        month_str = now.strftime("%Y-%m")
        if day_str != self.current_day:
            self.daily_pnl = 0.0
            self.trades_today = 0
            self.current_day = day_str
        if month_str != self.current_month:
            self.monthly_pnl = 0.0
            self.current_month = month_str

    # ── Trade gating ───────────────────────────────────────────

    def can_trade(self) -> tuple[bool, str]:
        self._sync_date()
        if self.halted:
            return False, f"HALTED: {self.halt_reason}"
        if self.trades_today >= config.MAX_TRADES_PER_DAY:
            return False, "Max trades/day reached"
        elapsed = time.time() - self.last_trade_ts
        if elapsed < config.MIN_INTERVAL_SECONDS:
            remaining = config.MIN_INTERVAL_SECONDS - elapsed
            return False, f"Min interval: wait {remaining:.0f}s"
        return True, "OK"

    # ── Update after trade ─────────────────────────────────────

    # ── Update after trade ─────────────────────────────────────

    def record_open(self):
        """Called when a new trade is opened."""
        self._sync_date()
        self.trades_today += 1
        self.last_trade_ts = time.time()
        self.save()

    def update_with_pnl(self, pnl: float):
        """Called when a trade is closed (profit or loss)."""
        self._sync_date()
        self.daily_pnl += pnl
        self.monthly_pnl += pnl
        self.capital += pnl
        
        if self.capital > self.peak:
            self.peak = self.capital
            
        self._check_limits()
        self.save()

    def update_from_mt5(self):
        """Syncs closed trades from MT5 history to update PnL."""
        import MetaTrader5 as mt5
        
        if not mt5.terminal_info():
            return

        # Get history for today
        from_date = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        to_date = datetime.now(timezone.utc) + timedelta(days=1)
        
        history = mt5.history_deals_get(from_date, to_date)
        if history is None:
            return

        # Simple logic: Recalculate daily PnL from scratch based on MT5 history
        # avoiding double counting requires strictly using MT5 as source of truth for PnL
        
        total_pnl_today = 0.0
        for deal in history:
            if deal.symbol == config.MT5_SYMBOL and deal.entry == mt5.DEAL_ENTRY_OUT:
                total_pnl_today += deal.profit + deal.swap + deal.commission
        
        # Update internal state if different (simplification)
        # In a robust system, we would match trade IDs. 
        # Here we trust the daily sum.
        if abs(total_pnl_today - self.daily_pnl) > 0.01:
             diff = total_pnl_today - self.daily_pnl
             self.daily_pnl = total_pnl_today
             self.monthly_pnl += diff # Add the diff to month
             self.capital += diff
             self._check_limits()
             self.save()

    def _check_limits(self):
        dd = self.drawdown()

        # Drawdown progressif — Master Spec V2
        if dd >= config.MAX_DRAWDOWN:          # 7% → halt total
            self.halted           = True
            self.halt_reason      = f"Max drawdown {dd:.2%} — trading stoppé"
            self.kelly_multiplier = 0.0
        elif dd >= 0.05:
            self.kelly_multiplier = 0.25       # -75% sizing
        elif dd >= 0.03:
            self.kelly_multiplier = 0.50       # -50% sizing
        else:
            self.kelly_multiplier = 1.0

        # Stop journalier : -2% du capital courant (pas initial)
        if self.daily_pnl <= -getattr(config, "MAX_DAILY_LOSS", 0.02) * self.capital:
            self.halted      = True
            self.halt_reason = "Daily loss limit"

        # Stop mensuel
        if self.monthly_pnl <= -config.MAX_MONTHLY_LOSS * self.capital:
            self.halted      = True
            self.halt_reason = "Monthly loss limit"



    # ── Persistence ────────────────────────────────────────────

    def save(self, path: str | None = None):
        path = path or config.STATE_FILE
        os.makedirs(os.path.dirname(path), exist_ok=True)
        state = {
            "capital": self.capital,
            "peak": self.peak,
            "daily_pnl": self.daily_pnl,
            "monthly_pnl": self.monthly_pnl,
            "trades_today": self.trades_today,
            "last_trade_ts": self.last_trade_ts,
            "current_day": self.current_day,
            "current_month": self.current_month,
            "halted": self.halted,
            "halt_reason": self.halt_reason,
        }
        with open(path, "w") as f:
            json.dump(state, f, indent=2)

    def load(self, path: str | None = None):
        path = path or config.STATE_FILE
        if not os.path.exists(path):
            return self
        with open(path) as f:
            state = json.load(f)
        for k, v in state.items():
            setattr(self, k, v)
        self._sync_date()          # Reset daily if date changed
        return self

    def drawdown(self) -> float:
        return (self.peak - self.capital) / (self.peak + 1e-12)
