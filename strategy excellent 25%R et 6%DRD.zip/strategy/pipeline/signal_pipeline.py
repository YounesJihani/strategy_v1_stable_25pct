"""
Signal pipeline — orchestrates all decision layers.
Phase 3+4 upgrades: HTF Trend Filter, Vol Regime, Meta-Labeling, HMM Regime.
"""

import numpy as np
import pandas as pd
from strategy import config
from strategy.models.feature_engineering import (
    build_features, build_target,
    get_regime_features, get_prediction_features,
)
from strategy.models.gradient_boosting import ReturnPredictor
from strategy.models.isolation_forest import ConfidenceScorer
from strategy.models.validators.walk_forward import WalkForwardValidator
from strategy.models.validators.monte_carlo import MonteCarloValidator
from strategy.models.validators.bootstrap import BootstrapValidator
from strategy.models.meta_labeler import MetaLabeler
from strategy.models.hmm_regime import HMMRegimeDetector
from strategy.risk.position_sizer import quarter_kelly_size
from strategy.risk.stop_calculator import calculate_stops, calculate_rr15_stops
from strategy.risk.risk_monitor import RiskMonitor
from strategy.models.ict_precision_entry import surgical_score_mtf


class SignalPipeline:
    """
    Full multi-layer decision pipeline.
    Call evaluate() with the latest OHLCV DataFrame to get a trade signal.
    """

    def __init__(self):
        self.predictor     = ReturnPredictor()
        self.confidence    = ConfidenceScorer()
        self.wf_validator  = WalkForwardValidator()
        self.mc_validator  = MonteCarloValidator()
        self.bs_validator  = BootstrapValidator()
        self.meta_labeler  = MetaLabeler(threshold=config.META_LABEL_THRESHOLD)
        self.hmm_detector  = HMMRegimeDetector(n_states=3)

        # Training metrics (updated after fit)
        self.train_win_rate = 0.52
        self.train_avg_win  = 0.001
        self.train_avg_loss = 0.001

    # ── Training ───────────────────────────────────────────────

    def fit(self, df: pd.DataFrame, verbose: bool = True):
        """Full training on historical OHLCV bars."""
        if verbose:
            print("[Pipeline] Building features …")
        feats = build_features(df)
        target = build_target(df)
        pred_feats = get_prediction_features(feats)
        regime_feats = get_regime_features(feats)

        # Align
        valid = target.notna() & pred_feats.notna().all(axis=1)
        pred_feats = pred_feats.loc[valid]
        regime_feats = regime_feats.loc[valid]
        target = target.loc[valid]
        prices = df["close"].loc[valid]

        if verbose:
            print(f"[Pipeline] Training samples: {len(pred_feats)}")

        # 1. GBR
        if verbose:
            print("[Pipeline] Training GBR …")
        self.predictor.fit(pred_feats, target)

        # Compute training stats for Kelly
        train_preds = self.predictor.predict_array(pred_feats)
        correct = np.sign(train_preds) == np.sign(target.values)
        self.train_win_rate = float(correct.mean())
        wins = target.values[correct]
        losses = target.values[~correct]
        self.train_avg_win  = float(np.abs(wins).mean())  if len(wins)  else 0.001
        self.train_avg_loss = float(np.abs(losses).mean()) if len(losses) else 0.001

        # 2. IsolationForest
        if verbose:
            print("[Pipeline] Training IsolationForest …")
        self.confidence.fit(regime_feats)

        # 3. Walk-Forward score (pre-computed for reference)
        if verbose:
            print("[Pipeline] Walk-Forward validation …")
        self.wf_score_ref = self.wf_validator.score(pred_feats, target, prices)
        if verbose:
            print(f"  WF reference score: {self.wf_score_ref:.3f}")

        # 4. Monte Carlo
        if verbose:
            print("[Pipeline] Training MC models ...")
        self.mc_validator.fit(pred_feats, target)

        # 5. Bootstrap
        if verbose:
            print("[Pipeline] Training Bootstrap models ...")
        self.bs_validator.fit(pred_feats, target)

        # 6. Meta-Labeler (Phase 4.1)
        if verbose:
            print("[Pipeline] Training Meta-Labeler ...")
        train_preds_arr = self.predictor.predict_array(pred_feats)
        self.meta_labeler.fit(pred_feats, train_preds_arr, target.values)
        if verbose and self.meta_labeler.is_fitted:
            print("  Meta-Labeler: fitted OK")

        # 7. HMM Regime Detector (Phase 4.2)
        if verbose:
            print("[Pipeline] Training HMM Regime Detector ...")
        self.hmm_detector.fit(feats)
        if verbose and self.hmm_detector.is_fitted:
            print("  HMM Detector: fitted OK")

        if verbose:
            print("[Pipeline] Training complete.")

    # ── Live evaluation ────────────────────────────────────────

    def evaluate(
        self,
        df: pd.DataFrame,
        risk_monitor: RiskMonitor,
    ) -> dict:
        """
        Pipeline 8 couches — Master Spec V2 (RR=1.5, ICT+MTF).
        Retourne un signal dict.
        """
        result = {"execute": False, "direction": 0, "reason": "", "scores": {}}

        feats    = build_features(df)
        pred_f   = get_prediction_features(feats)
        regime_f = get_regime_features(feats)
        ict_f    = surgical_score_mtf(df, feats)

        last_idx = feats.index[-1]
        if pred_f.loc[last_idx].isna().any():
            result["reason"] = "Features contain NaN"
            return result

        # ── COUCHE 1 : Risk Gate ───────────────────────────────
        can, msg = risk_monitor.can_trade()
        if not can:
            result["reason"] = f"Risk: {msg}"
            return result

        # ── COUCHE 2 : Kill Zone obligatoire ───────────────────────
        in_kz = bool(feats["in_killzone"].iloc[-1]) if "in_killzone" in feats.columns else False
        if not in_kz:
            result["reason"] = "Outside Kill Zone (London/NY/London-Close)"
            return result

        # ── COUCHE 3 : Biais MTF H1 minimum ─────────────────────
        h1_bias = float(feats["h1_bias"].iloc[-1]) if "h1_bias" in feats.columns else 0.0
        h4_bias = float(feats["h4_bias"].iloc[-1]) if "h4_bias" in feats.columns else 0.0
        result["scores"]["h1_bias"] = h1_bias
        result["scores"]["h4_bias"] = h4_bias

        # ── COUCHE 4 : LightGBM Classifier (60% min) ──────────────
        pred_row   = pred_f.loc[[last_idx]]
        prediction = self.predictor.predict(pred_row)
        conf = prediction.get("confidence", 0.0)
        result["scores"]["lgbm"] = conf

        if not self.predictor.passes_threshold(prediction):
            result["reason"] = f"LGBM conf faible: {conf:.3f} < {self.predictor.conf_min:.3f}"
            return result

        direction = prediction["signal_direction"]

        # Vérifier alignement avec biais HTF
        if h1_bias != 0 and h1_bias != direction:
            result["reason"] = f"Contre biais H1 ({h1_bias:+.0f})"
            return result

        # ── COUCHE 5 : Score Chirurgical ICT ─────────────────────
        surg_col = "bull_final" if direction == 1 else "bear_final"
        surg = float(ict_f[surg_col].iloc[-1]) if surg_col in ict_f.columns else 0.0
        result["scores"]["surgical"] = surg
        if surg < 0.25:
            result["reason"] = f"ICT surgical score insuffisant: {surg:.2f} < 0.25"
            return result

        # ── COUCHE 6 : Premium/Discount Zone correcte ─────────────
        pd_val = float(feats["pd_zone"].iloc[-1]) if "pd_zone" in feats.columns else 0.0
        result["scores"]["pd_zone"] = pd_val
        if direction == 1 and pd_val > 0.15:
            result["reason"] = f"Long en zone Premium: {pd_val:.2f}"
            return result
        if direction == -1 and pd_val < -0.15:
            result["reason"] = f"Short en zone Discount: {pd_val:.2f}"
            return result

        # ── COUCHE 7 : IsolationForest régime ────────────────────
        regime_row    = regime_f.loc[[last_idx]]
        ok_if, if_sc  = self.confidence.passes(regime_row)
        result["scores"]["isolation_forest"] = if_sc
        if if_sc < config.IF_CONFIDENCE_MIN:
            result["reason"] = f"IF régime hostile: {if_sc:.3f} < {config.IF_CONFIDENCE_MIN}"
            return result

        # ── COUCHE 8 : Score Composite Final ─────────────────────
        composite = conf * 0.40 + surg * 0.35 + if_sc * 0.25
        result["scores"]["composite"] = composite
        comp_min = getattr(config, "COMPOSITE_CONF_MIN", 0.52)
        if composite < comp_min:
            result["reason"] = f"Composite: {composite:.3f} < {comp_min:.2f}"
            return result

        # ── EXÉCUTION ──────────────────────────────────────────
        capital = risk_monitor.capital
        pos_size = quarter_kelly_size(
            self.train_win_rate, self.train_avg_win, self.train_avg_loss, capital
        )
        pos_size *= risk_monitor.kelly_multiplier

        atr   = float(feats["atr_raw"].iloc[-1])
        entry = float(df["close"].iloc[-1])

        # Stops chiurgicaux RR=1.5
        sl, tp, pos_size, trail = calculate_rr15_stops(
            entry, direction, atr, capital, pos_size, df, feats
        )

        result.update({
            "execute"   : True,
            "direction" : direction,
            "entry"     : entry,
            "sl"        : sl,
            "tp"        : tp,
            "volume"    : pos_size,
            "trail"     : trail,
            "reason"    : "ALL 8 LAYERS PASSED",
        })
        result["scores"].update({
            "h1_bias"  : h1_bias,
            "h4_bias"  : h4_bias,
            "composite": composite,
        })
        return result

    # ── ACTION 5 : Confiance Composite ICT ─────────────────────

    def _composite_confidence(
        self,
        prediction: dict,
        feats: "pd.DataFrame",
        direction: int,
    ) -> tuple[float, dict]:
        """
        Score composite [0→1] basé sur 5 critères ICT pondérés.
        Seuil minimum configurable via COMPOSITE_CONF_MIN (défaut 0.50).

        Critères & poids :
          35% — confiance LightGBM  (0.5→1.0 normalisé)
          20% — Kill Zone active    (London 7-9h / NY 13-15h UTC)
          20% — Liquidity Sweep     (dans la direction du trade)
          15% — Premium/Discount    (acheter bas, vendre haut)
          10% — Fair Value Gap      (dans la direction du trade)
        """
        score   = 0.0
        details: dict = {}

        # 1. Confiance LGBM  (35%)
        lgbm_conf = float(prediction.get("confidence", 0.5))
        lgbm_contrib = ((lgbm_conf - 0.5) / 0.5) * 0.35
        score += lgbm_contrib
        details["lgbm"] = round(lgbm_conf, 3)

        # 2. Kill Zone  (20%)
        kz_lon = float(feats["kz_london"].iloc[-1]) if "kz_london" in feats.columns else 0.0
        kz_ny  = float(feats["kz_ny"].iloc[-1])     if "kz_ny"     in feats.columns else 0.0
        kz_ov  = float(feats.get("kz_overlap", feats.get("overlap_session", 0)).iloc[-1]) if any(
            c in feats.columns for c in ("kz_overlap", "overlap_session")) else 0.0
        in_kz  = bool(kz_lon or kz_ny or kz_ov)
        score += 0.20 if in_kz else 0.0
        details["killzone"] = in_kz

        # 3. Liquidity Sweep dans la direction  (20%)
        if direction == 1:
            sweep = float(feats["sweep_bull"].iloc[-1]) if "sweep_bull" in feats.columns else 0.0
        else:
            sweep = float(feats["sweep_bear"].iloc[-1]) if "sweep_bear" in feats.columns else 0.0
        score += 0.20 if sweep else 0.0
        details["sweep"] = bool(sweep)

        # 4. Premium/Discount zone correcte  (15%)
        pd_val = float(feats["pd_zone"].iloc[-1]) if "pd_zone" in feats.columns else 0.0
        correct_zone = (direction ==  1 and pd_val < -0.2) or \
                       (direction == -1 and pd_val >  0.2)
        score += 0.15 if correct_zone else 0.0
        details["pd_zone"] = round(pd_val, 3)

        # 5. Fair Value Gap dans la direction  (10%)
        if direction == 1:
            fvg = float(feats["fvg_bull"].iloc[-1]) if "fvg_bull" in feats.columns else 0.0
        else:
            fvg = float(feats["fvg_bear"].iloc[-1]) if "fvg_bear" in feats.columns else 0.0
        score += 0.10 if fvg else 0.0
        details["fvg"] = bool(fvg)

        return round(score, 3), details

    # ── Persistence ────────────────────────────────────────────

    def save(self):
        self.predictor.save()
        self.confidence.save()
        self.mc_validator.save()
        self.bs_validator.save()
        if self.meta_labeler.is_fitted:
            self.meta_labeler.save()
        if self.hmm_detector.is_fitted:
            self.hmm_detector.save()

    def load(self):
        self.predictor.load()
        self.confidence.load()
        self.mc_validator.load()
        self.bs_validator.load()
        self.meta_labeler.load()
        self.hmm_detector.load()
        return self
