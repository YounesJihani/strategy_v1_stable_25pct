"""
Debug les 13 trades du backtest pour analyser SL/TP et direction.
"""
import pandas as pd
import numpy as np
import MetaTrader5 as mt5
from strategy.models.feature_engineering import build_features, build_target, get_prediction_features, get_regime_features
from strategy.models.gradient_boosting import ReturnPredictor
from strategy.models.isolation_forest import ConfidenceScorer
from strategy.models.validators.walk_forward import WalkForwardValidator
from strategy.models.validators.monte_carlo import MonteCarloValidator
from strategy.models.validators.bootstrap import BootstrapValidator
from strategy.risk.position_sizer import quarter_kelly_size
from strategy.risk.stop_calculator import calculate_rr15_stops
from strategy.models.ict_precision_entry import surgical_score_mtf
from strategy import config

mt5.initialize()
rates = mt5.copy_rates_from_pos("EURUSD", mt5.TIMEFRAME_M5, 0, 5000)
df = pd.DataFrame(rates)
df["time"] = pd.to_datetime(df["time"], unit="s")

n = len(df)
split = int(n * 0.70)
df_train = df.iloc[:split].copy()
df_test  = df.iloc[split:].copy()

print(f"Total: {n} | Train: {split} | Test: {n-split}")

feats_all = build_features(df)
target_all = build_target(df)
pred_feats = get_prediction_features(feats_all)
regime_feats = get_regime_features(feats_all)

pred_train = pred_feats.iloc[:split]
target_train = target_all.iloc[:split]
regime_train = regime_feats.iloc[:split]

predictor = ReturnPredictor()
confidence = ConfidenceScorer()

valid_mask = target_train.notna() & pred_train.notna().all(axis=1)
predictor.fit(pred_train.loc[valid_mask], target_train.loc[valid_mask])
confidence.fit(regime_train.loc[regime_train.notna().all(axis=1)])

mc_val = MonteCarloValidator()
bs_val = BootstrapValidator()
mc_val.fit(pred_train.loc[valid_mask], target_train.loc[valid_mask])
bs_val.fit(pred_train.loc[valid_mask], target_train.loc[valid_mask])
wf_val = WalkForwardValidator()
prices_train = df_train["close"].loc[valid_mask]
wf_score = wf_val.score(pred_train.loc[valid_mask], target_train.loc[valid_mask], prices_train)

# ICT scores
ict_scores = surgical_score_mtf(df, feats_all)

test_indices = df.index[split:]
pred_test = pred_feats.loc[test_indices].fillna(0)
regime_test = regime_feats.loc[test_indices].fillna(0)

mc_scores = mc_val.score_batch(pred_test)
mc_dirs = mc_val.direction_batch(pred_test)
bs_scores = bs_val.score_batch(pred_test)
bs_dirs = bs_val.direction_batch(pred_test)
gbr_preds = predictor.predict_batch(pred_test)
confidence_mask = confidence.batch_passes(regime_test)

print(f"\nWF score: {wf_score:.3f}")
print(f"\nFiltre IsolationForest passe: {confidence_mask.mean():.2%}")

# Scan des barres test
trade_count = 0
n_test = n - split

for i in range(200, n_test - config.FORWARD_PERIOD):
    test_idx = split + i
    
    if not confidence_mask.iloc[i]:
        continue
    
    prediction = gbr_preds[i]
    if not predictor.passes_threshold(prediction):
        continue
    gbr_dir = prediction["signal_direction"]
    
    mc_score = mc_scores.iloc[i]
    if mc_score < config.MC_THRESHOLD:
        continue
    mc_dir = mc_dirs.iloc[i]
    
    bs_score = bs_scores.iloc[i]
    if bs_score < config.BS_THRESHOLD:
        continue
    bs_dir = bs_dirs.iloc[i]
    
    if wf_score < config.WF_THRESHOLD:
        continue
    
    directions = [gbr_dir, mc_dir, bs_dir]
    long_votes  = directions.count(1)
    short_votes = directions.count(-1)
    if long_votes >= 2:
        trade_dir = 1
    elif short_votes >= 2:
        trade_dir = -1
    else:
        continue
    
    ctx_idx = test_idx  # RangeIndex
    
    def _scalar(col):
        v = feats_all[col].iloc[ctx_idx]
        if isinstance(v, pd.Series): v = v.iloc[0]
        return float(v)
    
    in_kz = bool(_scalar("in_killzone")) if "in_killzone" in feats_all.columns else False
    if not in_kz:
        continue
    
    h1_bias = _scalar("h1_bias") if "h1_bias" in feats_all.columns else 0.0
    if h1_bias != 0 and h1_bias != trade_dir:
        continue
    
    surg_col = "bull_final" if trade_dir == 1 else "bear_final"
    surg_val = float(ict_scores[surg_col].iloc[test_idx]) if surg_col in ict_scores.columns else 0.0
    if surg_val < 0.25:
        continue
    
    pd_val = _scalar("pd_zone") if "pd_zone" in feats_all.columns else 0.0
    if trade_dir == 1 and pd_val > 0.15:
        continue
    if trade_dir == -1 and pd_val < -0.15:
        continue
    
    atr_val = feats_all["atr_raw"].iloc[ctx_idx]
    atr = float(atr_val) if not isinstance(atr_val, pd.Series) else float(atr_val.iloc[0])
    if atr < 1e-12:
        continue
    
    bar = df.iloc[test_idx]
    price = float(bar["close"])
    
    pos_size = quarter_kelly_size(0.57, 1.0, 0.53, 10000)
    ctx_df = df.iloc[max(0, test_idx-10):test_idx+1]
    ctx_feats = feats_all.iloc[max(0, test_idx-10):test_idx+1]
    sl, tp, pos_size, trail = calculate_rr15_stops(price, trade_dir, atr, 10000, pos_size, ctx_df, ctx_feats)
    
    sl_dist = abs(price - sl)
    tp_dist = abs(tp - price)
    rr = tp_dist / (sl_dist + 1e-12)
    
    trade_count += 1
    time_str = pd.to_datetime(df.iloc[test_idx]["time"], unit="s") if not pd.api.types.is_datetime64_any_dtype(df["time"]) else df.iloc[test_idx]["time"]
    print(f"\nTrade #{trade_count} | Bar {test_idx} | {df.iloc[test_idx]['time']}")
    print(f"  Dir={trade_dir} | Entry={price:.5f} | SL={sl:.5f} | TP={tp:.5f}")
    print(f"  SL_dist={sl_dist*10000:.1f}pip | TP_dist={tp_dist*10000:.1f}pip | RR={rr:.2f}")
    print(f"  ATR={atr*10000:.1f}pip | Surg={surg_val:.3f} | H1_bias={h1_bias} | PD={pd_val:.3f}")
    print(f"  GBR_conf={prediction['confidence']:.3f} | MC={mc_score:.3f} | BS={bs_score:.3f}")
    
    if trade_count >= 20:
        print("\n... (limité à 20 trades)")
        break

print(f"\nTotal trades avec filtres ICT: {trade_count}")
