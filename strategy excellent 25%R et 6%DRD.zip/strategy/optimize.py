"""
Phase 4.3 — Bayesian Hyperparameter Optimization via Optuna
Uses TPE sampler to find optimal strategy parameters on validation set only.
Test set is NEVER touched during optimization (data leakage prevention).

Usage:
    python -m strategy.optimize --trials 200
    python -m strategy.optimize --trials 100 --jobs 1

Requires: pip install optuna
"""
import sys, argparse, json, os
import pandas as pd
import numpy as np

# UTF-8 for Windows console
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

try:
    import optuna
    optuna.logging.set_verbosity(optuna.logging.WARNING)
    _OPTUNA_AVAILABLE = True
except ImportError:
    _OPTUNA_AVAILABLE = False

from strategy import config
from strategy.backtest.tick_backtester import BarBacktester


# ─── Data loading ──────────────────────────────────────────────
def load_data() -> pd.DataFrame:
    import MetaTrader5 as mt5
    from datetime import datetime, timedelta, timezone

    if not mt5.initialize(
        login=config.MT5_LOGIN,
        password=config.MT5_PASSWORD,
        server=config.MT5_SERVER,
    ):
        raise RuntimeError(f"MT5 init failed: {mt5.last_error()}")

    tf_map = {"M1": mt5.TIMEFRAME_M1, "M5": mt5.TIMEFRAME_M5, "H1": mt5.TIMEFRAME_H1}
    tf = tf_map.get(config.MT5_TIMEFRAME_NAME, mt5.TIMEFRAME_M5)

    date_to   = datetime.now(timezone.utc)
    date_from = date_to - timedelta(days=config.BACKTEST_MONTHS * 30)
    rates = mt5.copy_rates_range(config.MT5_SYMBOL, tf, date_from, date_to)
    mt5.shutdown()

    if rates is None or len(rates) == 0:
        raise RuntimeError("No data returned from MT5")

    df = pd.DataFrame(rates)
    df["time"] = pd.to_datetime(df["time"], unit="s")
    return df


# ─── Objective function ────────────────────────────────────────
def objective(trial, df_train: pd.DataFrame, df_val: pd.DataFrame) -> float:
    """
    Trains on df_train, evaluates on df_val.
    Returns composite score (higher = better).
    """
    # Suggest parameters within safe bounds
    config.SL_ATR_MULT        = trial.suggest_float("SL_ATR_MULT",       1.0,  2.5)
    config.MIN_RR_RATIO       = trial.suggest_float("MIN_RR_RATIO",      1.2,  3.0)
    config.FORWARD_PERIOD     = trial.suggest_int(  "FORWARD_PERIOD",    3,    16)
    config.IF_CONFIDENCE_MIN  = trial.suggest_float("IF_CONFIDENCE_MIN", 0.25, 0.55)
    config.MC_THRESHOLD       = trial.suggest_float("MC_THRESHOLD",      0.38, 0.60)
    config.BS_THRESHOLD       = trial.suggest_float("BS_THRESHOLD",      0.38, 0.60)
    config.OU_ZSCORE_MIN      = trial.suggest_float("OU_ZSCORE_MIN",     0.50, 1.80)
    config.OU_THETA_MIN       = trial.suggest_float("OU_THETA_MIN",      0.001, 0.01)
    config.CONSENSUS_THRESHOLD= trial.suggest_float("CONSENSUS_THRESHOLD", 0.38, 0.55)

    try:
        # Combine train+val for full training, then evaluate only on val
        df_combined = pd.concat([df_train, df_val], ignore_index=True)
        config_split_ratio = len(df_train) / len(df_combined)

        bt = BarBacktester(
            initial_capital=10_000.0,
            train_ratio=config_split_ratio,
        )
        results = bt.run(df_combined, verbose=False)
        m = results.get("test_metrics", {})

        n_trades = m.get("n_trades", 0)
        if n_trades < 30:
            return -999.0  # Needs minimum trade count for statistical relevance

        p_value = m.get("p_value", 1.0)
        if p_value > 0.10:
            return -999.0  # Not statistically meaningful

        # Composite score — maximize Sharpe-weighted Profit Factor, penalize drawdown
        sharpe  = float(m.get("sharpe", -5.0))
        pf      = float(m.get("profit_factor", 0.5))
        dd      = float(m.get("max_drawdown", 0.20))
        wr      = float(m.get("win_rate", 0.0))

        score = (
            sharpe       * 0.35 +
            pf           * 0.25 -
            dd           * 25.0 * 0.25 +   # Penalize drawdown heavily
            wr           * 0.15
        )
        return score

    except Exception as e:
        return -999.0


# ─── Main optimization loop ────────────────────────────────────
def run_optimization(
    df: pd.DataFrame,
    n_trials: int = 200,
    n_jobs: int = 1,
    output_path: str | None = None,
) -> dict:
    """
    Runs Bayesian optimization.
    Split: 60% train | 20% validation | 20% test (test NEVER touched here).
    """
    if not _OPTUNA_AVAILABLE:
        print("[Optimize] optuna not installed. Run: pip install optuna")
        return {}

    n = len(df)
    df_train = df.iloc[:int(n * 0.60)].reset_index(drop=True)
    df_val   = df.iloc[int(n * 0.60):int(n * 0.80)].reset_index(drop=True)
    # df_test  = df.iloc[int(n*0.80):]   # <- NEVER USE IN optimization

    print(f"[Optimize] Train: {len(df_train):,} bars | Val: {len(df_val):,} bars")
    print(f"[Optimize] Running {n_trials} trials (TPE sampler) ...")

    study = optuna.create_study(
        direction="maximize",
        sampler=optuna.samplers.TPESampler(seed=42, n_startup_trials=20),
        pruner=optuna.pruners.MedianPruner(n_startup_trials=10, n_warmup_steps=5),
    )
    study.optimize(
        lambda t: objective(t, df_train, df_val),
        n_trials=n_trials,
        n_jobs=n_jobs,
        show_progress_bar=True,
    )

    best_params = study.best_params
    best_score  = study.best_value

    print("\n" + "=" * 60)
    print("  BAYESIAN OPTIMIZATION RESULTS")
    print("=" * 60)
    print(f"  Best Score  : {best_score:.4f}")
    print(f"  Best Params :")
    for k, v in best_params.items():
        print(f"    {k:30s} = {v}")
    print("=" * 60)

    # Save results
    output_path = output_path or os.path.join(config.BASE_DIR, "optuna_best_params.json")
    with open(output_path, "w") as f:
        json.dump({"score": best_score, "params": best_params}, f, indent=2)
    print(f"[Optimize] Results saved to {output_path}")

    return best_params


def apply_best_params(params: dict):
    """Apply the optimized parameters to config."""
    for k, v in params.items():
        if hasattr(config, k):
            setattr(config, k, v)
            print(f"[Config] {k} = {v}")


# ── CLI entry point ─────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Bayesian optimization for trading strategy")
    parser.add_argument("--trials", type=int, default=200, help="Number of Optuna trials")
    parser.add_argument("--jobs",   type=int, default=1,   help="Parallel jobs (-1 = all CPUs)")
    parser.add_argument("--apply",  action="store_true",   help="Apply best params to config")
    args = parser.parse_args()

    print("[Optimize] Loading data from MT5 ...")
    df = load_data()
    print(f"[Optimize] {len(df):,} bars loaded")

    best = run_optimization(df, n_trials=args.trials, n_jobs=args.jobs)

    if args.apply and best:
        apply_best_params(best)
        print("[Optimize] Best params applied to config.")
