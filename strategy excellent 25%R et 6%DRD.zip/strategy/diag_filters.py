"""
Diagnostic des filtres ICT — Master Spec V2
"""
import pandas as pd
import numpy as np
import MetaTrader5 as mt5
from strategy.models.feature_engineering import build_features
from strategy.models.ict_precision_entry import surgical_score_mtf

mt5.initialize()
rates = mt5.copy_rates_from_pos("EURUSD", mt5.TIMEFRAME_M5, 0, 3000)
df = pd.DataFrame(rates)
df["time"] = pd.to_datetime(df["time"], unit="s")
df.set_index("time", inplace=True)

feats = build_features(df)

print("=== COLONNES ICT DISPONIBLES ===")
ict_cols = [c for c in feats.columns if c in [
    "in_killzone","h1_bias","pd_zone","sweep_bull","sweep_bear",
    "fvg_bull","fvg_bear","is_london","is_newyork","kz_london_close"
]]
print(ict_cols)
print()

if "in_killzone" in feats.columns:
    print(f"Kill Zone taux: {feats['in_killzone'].mean():.2%}")

if "h1_bias" in feats.columns:
    print("H1 bias dist:", feats["h1_bias"].value_counts().to_dict())

if "pd_zone" in feats.columns:
    pz = feats["pd_zone"]
    print(f"PD zone mean={pz.mean():.3f} std={pz.std():.3f}")
    print(f"  > +0.15 (bloque LONG): {(pz > 0.15).mean():.2%}")
    print(f"  < -0.15 (bloque SHORT): {(pz < -0.15).mean():.2%}")

ict = surgical_score_mtf(df, feats)
print(f"\nBull_final >= 0.25: {(ict['bull_final'] >= 0.25).mean():.2%}")
print(f"Bear_final >= 0.25: {(ict['bear_final'] >= 0.25).mean():.2%}")
print(f"Bull_final mean: {ict['bull_final'].mean():.3f}")
print(f"Bear_final mean: {ict['bear_final'].mean():.3f}")

print("\n=== DISTRIBUTION Bull_final ===")
print(ict["bull_final"].describe())

# Simulate combined filter rate
in_kz = feats.get("in_killzone", pd.Series(True, index=feats.index))
h1_bias = feats.get("h1_bias", pd.Series(0.0, index=feats.index))
pd_zone = feats.get("pd_zone", pd.Series(0.0, index=feats.index))

bull_pass = (
    (in_kz == 1) &
    ((h1_bias == 0) | (h1_bias == 1)) &
    (ict["bull_final"] >= 0.25) &
    (pd_zone <= 0.15)
)
bear_pass = (
    (in_kz == 1) &
    ((h1_bias == 0) | (h1_bias == -1)) &
    (ict["bear_final"] >= 0.25) &
    (pd_zone >= -0.15)
)
print(f"\nSignaux BULL passent filtres ICT: {bull_pass.mean():.2%}")
print(f"Signaux BEAR passent filtres ICT: {bear_pass.mean():.2%}")
print(f"Au moins 1 côté: {(bull_pass | bear_pass).mean():.2%}")
