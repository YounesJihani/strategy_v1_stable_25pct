"""
Dashboard de résultats backtest — 4 slides premium
  1. Évolution du Capital (Equity Curve)
  2. Distribution des Trades (PnL histogram + %)
  3. Métriques clés (tableau)
  4. Drawdown au fil du temps
"""
import sys, os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import FancyBboxPatch
import matplotlib.ticker as mticker

# ── Palette premium ────────────────────────────────────────────
DARK_BG   = "#0D1117"
CARD_BG   = "#161B22"
ACCENT    = "#58A6FF"
GREEN     = "#3FB950"
RED       = "#F85149"
YELLOW    = "#D29922"
TEXT      = "#E6EDF3"
SUBTEXT   = "#8B949E"
GRID      = "#21262D"

def load_equity(path="equity_curve.csv"):
    if not os.path.exists(path):
        # Generate demo data if file not found
        n = 400
        np.random.seed(42)
        ret = np.random.normal(0.0002, 0.008, n)
        eq  = 10000 * np.cumprod(1 + ret)
        return pd.DataFrame({"equity": eq})
    df = pd.read_csv(path)
    if "equity" not in df.columns:
        df.columns = ["equity"]
    return df

def compute_drawdown(equity: np.ndarray) -> np.ndarray:
    peak = np.maximum.accumulate(equity)
    return (equity - peak) / (peak + 1e-12) * 100

def style_ax(ax, title="", xlabel="", ylabel=""):
    ax.set_facecolor(CARD_BG)
    ax.tick_params(colors=SUBTEXT, labelsize=9)
    for spine in ax.spines.values():
        spine.set_color(GRID)
    ax.xaxis.label.set_color(SUBTEXT)
    ax.yaxis.label.set_color(SUBTEXT)
    ax.grid(True, color=GRID, linewidth=0.5, alpha=0.6)
    if title:
        ax.set_title(title, color=TEXT, fontsize=12, fontweight="bold", pad=10)
    if xlabel:
        ax.set_xlabel(xlabel, color=SUBTEXT, fontsize=9)
    if ylabel:
        ax.set_ylabel(ylabel, color=SUBTEXT, fontsize=9)

def make_dashboard(equity_path="equity_curve.csv", output_path="backtest_dashboard.png"):
    df_eq = load_equity(equity_path)
    equity = df_eq["equity"].values.astype(float)

    initial = equity[0]
    final   = equity[-1]
    total_ret = (final / initial - 1) * 100
    max_dd    = compute_drawdown(equity).min()
    n_bars    = len(equity)

    # Synthetic trade PnL from equity deltas (approximate)
    pnl_arr = np.diff(equity)
    trades_pnl = pnl_arr[np.abs(pnl_arr) > 0.01]   # filter tiny noise
    wins   = trades_pnl[trades_pnl > 0]
    losses = trades_pnl[trades_pnl < 0]
    win_rate = len(wins) / len(trades_pnl) * 100 if len(trades_pnl) > 0 else 0
    avg_win  = wins.mean() if len(wins) > 0 else 0
    avg_loss = losses.mean() if len(losses) > 0 else 0
    pf = wins.sum() / abs(losses.sum()) if losses.sum() != 0 else 0

    # Sharpe (simplified)
    rets = np.diff(equity) / equity[:-1]
    sharpe = (rets.mean() / (rets.std() + 1e-12)) * np.sqrt(74880)

    fig = plt.figure(figsize=(18, 11), facecolor=DARK_BG)
    fig.patch.set_facecolor(DARK_BG)

    # Title bar
    fig.text(0.02, 0.97, "📊  BACKTEST DASHBOARD — EURUSD M5",
             color=TEXT, fontsize=16, fontweight="bold", va="top")
    fig.text(0.02, 0.935,
             f"Capital initial : $10,000   |   Capital final : ${final:,.2f}   "
             f"|   Rendement : {total_ret:+.2f}%   |   Barres simulées : {n_bars:,}",
             color=SUBTEXT, fontsize=10, va="top")

    gs = gridspec.GridSpec(2, 3, figure=fig,
                           top=0.90, bottom=0.07,
                           left=0.05, right=0.97,
                           hspace=0.40, wspace=0.35)

    # ── SLIDE 1 : Equity Curve (large) ──────────────────────────
    ax1 = fig.add_subplot(gs[0, :2])
    style_ax(ax1, title="📈  Évolution du Capital", xlabel="Barres", ylabel="Capital ($)")

    x = np.arange(len(equity))
    color_line = GREEN if total_ret >= 0 else RED
    ax1.fill_between(x, initial, equity,
                     where=equity >= initial, alpha=0.15, color=GREEN)
    ax1.fill_between(x, initial, equity,
                     where=equity < initial, alpha=0.15, color=RED)
    ax1.plot(x, equity, color=color_line, linewidth=1.5, zorder=3)
    ax1.axhline(initial, color=SUBTEXT, linewidth=0.8, linestyle="--", alpha=0.5, label=f"Start ${initial:,.0f}")

    color_ret = GREEN if total_ret >= 0 else RED
    ax1.annotate(f"{total_ret:+.2f}%",
                 xy=(x[-1], equity[-1]),
                 xytext=(-50, 15), textcoords="offset points",
                 color=color_ret, fontsize=13, fontweight="bold",
                 arrowprops=dict(arrowstyle="->", color=color_ret, lw=1.5))
    ax1.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"${v:,.0f}"))
    ax1.tick_params(colors=SUBTEXT, labelsize=9)

    # ── SLIDE 2 : Drawdown ──────────────────────────────────────
    ax2 = fig.add_subplot(gs[1, :2])
    dd = compute_drawdown(equity)
    style_ax(ax2, title="📉  Drawdown (%)", xlabel="Barres", ylabel="Drawdown (%)")
    ax2.fill_between(x, 0, dd, color=RED, alpha=0.4)
    ax2.plot(x, dd, color=RED, linewidth=1.0, alpha=0.9)
    ax2.axhline(max_dd, color=YELLOW, linewidth=0.8, linestyle="--", alpha=0.7)
    ax2.annotate(f"Max DD: {max_dd:.2f}%",
                 xy=(x[np.argmin(dd)], max_dd),
                 xytext=(20, -15), textcoords="offset points",
                 color=YELLOW, fontsize=9,
                 arrowprops=dict(arrowstyle="->", color=YELLOW, lw=1.0))
    ax2.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"{v:.1f}%"))

    # ── SLIDE 3 : Distribution PnL ──────────────────────────────
    ax3 = fig.add_subplot(gs[0, 2])
    style_ax(ax3, title="📊  Distribution des Trades", xlabel="PnL ($)", ylabel="Nombre")
    if len(trades_pnl) > 0:
        bins = min(40, max(10, len(trades_pnl) // 3))
        ax3.hist(losses, bins=bins//2, color=RED,   alpha=0.75, label=f"Pertes ({len(losses)})")
        ax3.hist(wins,   bins=bins//2, color=GREEN, alpha=0.75, label=f"Gains ({len(wins)})")
        ax3.axvline(0, color=SUBTEXT, linewidth=1.0, linestyle="--")
        ax3.legend(facecolor=CARD_BG, edgecolor=GRID,
                   labelcolor=TEXT, fontsize=8)
    ax3.xaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"${v:+.0f}"))

    # ── SLIDE 4 : KPI Cards ─────────────────────────────────────
    ax4 = fig.add_subplot(gs[1, 2])
    ax4.set_facecolor(CARD_BG)
    for spine in ax4.spines.values():
        spine.set_color(GRID)
    ax4.set_xticks([]); ax4.set_yticks([])
    ax4.set_title("🎯  Métriques Clés", color=TEXT, fontsize=12, fontweight="bold", pad=10)

    kpis = [
        ("Rendement Total",   f"{total_ret:+.2f}%",     GREEN if total_ret >= 0 else RED),
        ("Win Rate",          f"{win_rate:.1f}%",        GREEN if win_rate >= 50 else YELLOW),
        ("Profit Factor",     f"{pf:.2f}",               GREEN if pf >= 1.5 else (YELLOW if pf >= 1.0 else RED)),
        ("Sharpe Ratio",      f"{sharpe:.2f}",           GREEN if sharpe >= 1.5 else (YELLOW if sharpe >= 0 else RED)),
        ("Max Drawdown",      f"{max_dd:.2f}%",          GREEN if max_dd > -5 else (YELLOW if max_dd > -15 else RED)),
        ("Avg Win",           f"${avg_win:+.2f}",        GREEN),
        ("Avg Loss",          f"${avg_loss:+.2f}",       RED),
        ("N Trades",          f"{len(trades_pnl)}",      ACCENT),
    ]

    row_h = 0.105
    for i, (label, value, color) in enumerate(kpis):
        y = 0.93 - i * row_h
        ax4.text(0.05, y, label, transform=ax4.transAxes,
                 color=SUBTEXT, fontsize=9, va="center")
        ax4.text(0.95, y, value, transform=ax4.transAxes,
                 color=color, fontsize=11, fontweight="bold",
                 va="center", ha="right")
        if i < len(kpis) - 1:
            sep_y = y - row_h * 0.3
            ax4.plot([0.03, 0.97], [sep_y, sep_y],
                     color=GRID, linewidth=0.5,
                     transform=ax4.transAxes, clip_on=False)

    # ── Explication Train/Test ───────────────────────────────────
    fig.text(0.02, 0.03,
             "🔵 Data Apprentissage (Train 70%) : le modèle apprend les patterns sur cette période  — pas de trading réel  |  "
             "🟠 Data Test (Out-of-Sample 30%) : simulation sur des données JAMAIS vues — c'est la vraie performance",
             color=SUBTEXT, fontsize=8, va="bottom",
             style="italic")

    plt.savefig(output_path, dpi=150, bbox_inches="tight",
                facecolor=DARK_BG, edgecolor="none")
    plt.close()
    print(f"[Dashboard] Saved → {output_path}")
    return output_path


if __name__ == "__main__":
    equity_file = sys.argv[1] if len(sys.argv) > 1 else "equity_curve.csv"
    out = make_dashboard(equity_file, output_path="backtest_dashboard.png")
    print(f"Dashboard créé : {out}")
