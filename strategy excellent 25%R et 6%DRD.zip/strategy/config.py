"""
Centralized configuration — Master Spec V2 : RR=1.5 | Win Rate 58-62% | ICT+MTF
"""
import os

# ─── MT5 Credentials ───────────────────────────────────────────
MT5_LOGIN    = 10009707359
MT5_PASSWORD = "@gP7YeUr"
MT5_SERVER   = "MetaQuotes-Demo"
MT5_SYMBOL   = "EURUSD"
MT5_TIMEFRAME_NAME = "M5"

# ─── Paths ─────────────────────────────────────────────────────
BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
MODELS_DIR  = os.path.join(BASE_DIR, "saved_models")
STATE_FILE  = os.path.join(BASE_DIR, "state.json")

# ─── Feature Engineering ───────────────────────────────────────
RETURN_WINDOWS     = [1, 5, 10, 20, 50]
VOLATILITY_WINDOWS = [5, 10, 20]
MOMENTUM_WINDOWS   = [3, 7, 14]
RSI_PERIODS        = [7, 14]
MACD_PARAMS        = (12, 26, 9)
BOLLINGER_PERIOD   = 20
BOLLINGER_STD      = 2.0
ATR_PERIOD         = 14
VOLUME_MA_PERIOD   = 20
SPREAD_MA_PERIOD   = 5
SR_LOOKBACK        = 50
FORWARD_PERIOD     = 12     # 1h — fenêtre plus robuste pour RR=1.5 sur M5

# ─── LightGBM — optimisé pour Win Rate élevé (Master Spec V2) ──
LGBM_PARAMS: dict = dict(
    n_estimators     = 400,    # Plus de trees pour RR=1.5
    max_depth        = 4,
    learning_rate    = 0.02,   # Réduit pour meilleure généralisation
    num_leaves       = 16,     # Réduit pour éviter overfitting
    subsample        = 0.75,
    colsample_bytree = 0.75,
    min_child_samples= 40,     # Augmenté pour robustesse
    reg_alpha        = 0.15,
    reg_lambda       = 0.25,
    random_state     = 42,
    verbose          = -1,
)
GBR_PARAMS = LGBM_PARAMS   # alias legacy

# ─── Seuils de Confiance ────────────────────────────────────────
LGBM_CONF_MIN       = 0.60   # Seuil élevé : 60% min → WR supérieur
COMPOSITE_CONF_MIN  = 0.52   # Score composite ICT [0→1]

# ─── Cibles de Win Rate (Master Spec V2) ────────────────────────
TARGET_WIN_RATE     = 0.58   # Minimum acceptable
TARGET_WIN_RATE_OPT = 0.62   # Objectif optimal

# ─── IsolationForest ────────────────────────────────────────────
IF_PARAMS = dict(
    n_estimators=100,
    contamination=0.1,
    max_samples="auto",
    max_features=1.0,
    bootstrap=False,
    random_state=42,
)

# ─── Validation Thresholds ──────────────────────────────────────
WF_WINDOWS         = 6       # 6 fenêtres WFO — validation rigoureuse
WF_TRAIN_DAYS      = 30
WF_VAL_DAYS        = 7
WF_PURGE_BARS      = 6       # Gap anti-autocorrélation
WF_MIN_WINRATE     = 0.50
WF_MIN_PF          = 1.02
WF_THRESHOLD       = 0.20    # Classifier : scores plus bas que Régresseur

# ─── Filtres Ornstein-Uhlenbeck ─────────────────────────────────
OU_ZSCORE_MIN       = 0.75
OU_THETA_MIN        = 0.001
HUNT_ZSCORE_MIN     = 2.0

# ─── Macro/Volatility Filters ───────────────────────────────────
MACRO_SURPRISE_MAX  = 2.8
MACRO_DECAY_MAX     = 1.8

# ─── Monte Carlo / Bootstrap ────────────────────────────────────
MC_N_MODELS         = 30
MC_FEATURE_FRAC     = 0.70
MC_STD_RATIO_MAX    = 0.60
MC_THRESHOLD        = 0.38

BS_N_SAMPLES        = 50
BS_THRESHOLD        = 0.38

CONSENSUS_WEIGHTS   = (0.40, 0.35, 0.25)
CONSENSUS_THRESHOLD = 0.38
IF_CONFIDENCE_MIN   = 0.30

# ─── Meta-Labeler / HTF / Vol Regime ──────────────────────────
META_LABEL_THRESHOLD  = 0.52
META_LABEL_ENABLED    = False
HTF_TREND_ENABLED     = False
HTF_SIGNAL_BYPASS_MAG = 0.50
VOL_REGIME_ENABLED    = False
VOL_REGIME_MIN        = 0.10
VOL_REGIME_MAX        = 0.90

# ─── Execution ──────────────────────────────────────────────────
TC_MULTIPLIER       = 3.5
MAX_TRADES_PER_DAY  = 5      # Augmenté : RR=1.5 crée plus d'opportunités
TRADE_MONDAY        = False
TRADE_FRIDAY        = False

# ─── Risk Management — RR=1.5 (Master Spec V2) ─────────────────
MIN_RR_RATIO        = 1.5    # CHANGÉ : RR=1.5 optimal M5
SL_ATR_MULT         = 1.2    # CHANGÉ : SL serré → RR=1.5 atteignable
MAX_RISK_PER_TRADE  = 0.005  # 0.5% par trade (pour drawdown < 7%)
MAX_DAILY_LOSS      = 0.02   # 2% stop journalier
MAX_MONTHLY_LOSS    = 0.08
MAX_DRAWDOWN        = 0.07   # 7% halt total — plus strict
MIN_RECOVERY_FACTOR = 3.0
KELLY_DIVISOR       = 6      # Plus prudent
KELLY_MAX_FRAC      = 0.02   # Max 2% par trade
KELLY_MIN_FRAC      = 0.005

# ─── Règles Opérationnelles ─────────────────────────────────────
MIN_INTERVAL_SECONDS         = 3600     # 1 trade min toutes les 1h
SESSION_OPEN_BUFFER_MIN      = 30
SESSION_CLOSE_BUFFER_MIN     = 15
NEWS_BUFFER_MIN              = 15
LATENCY_MS                   = 500
LATENCY_ATR_CANCEL_RATIO     = 0.50

# ─── Re-entraînement Automatique ───────────────────────────────
RETRAIN_INTERVAL_DAYS        = 14
RETRAIN_LOOKBACK_MONTHS      = 6

# ─── Backtest — 5 ans minimum (Master Spec V2) ─────────────────
BACKTEST_MONTHS              = 60      # 5 ans minimum (était 18)
CHUNK_SIZE                   = 500_000
TRANSACTION_COST_BPS         = 0.4    # CHANGÉ : 0.4 bps (0.4 pips spread EURUSD)

# ─── Métriques cibles (Master Spec V2) ─────────────────────────
TARGET_METRICS = dict(
    win_rate        = 0.58,   # CHANGÉ : 58% minimum
    profit_factor   = 2.0,    # CHANGÉ : PF 2.0 avec RR=1.5
    sharpe          = 1.8,
    sortino         = 2.5,
    max_drawdown    = 0.07,
    calmar          = 3.0,
    min_trades      = 300,    # AUGMENTÉ : RR=1.5 = plus de trades
    recovery_factor = 4.0,
    pvalue          = 0.05,
)
