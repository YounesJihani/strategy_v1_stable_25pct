"""
Script de validation étape par étape des modèles.
Entraîne et évalue chaque composant séparément pour valider la performance individuelle.
"""

import sys, os
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from strategy import config
from strategy.models.feature_engineering import build_features, build_target, get_prediction_features, get_regime_features
from strategy.models.gradient_boosting import ReturnPredictor
from strategy.models.isolation_forest import ConfidenceScorer
from strategy.models.validators.monte_carlo import MonteCarloValidator
from strategy.models.validators.bootstrap import BootstrapValidator
from strategy.execution.order_manager import init_mt5, shutdown_mt5
from strategy.train_and_backtest import download_data

def evaluate_directional_accuracy(y_true, y_pred, name="Model"):
    mask = (y_true != 0) & (y_pred != 0)
    if mask.sum() == 0:
        print(f"[{name}] Pas de signaux directionnels communs.")
        return
    
    y_t = np.sign(y_true[mask])
    y_p = np.sign(y_pred[mask])
    
    acc = accuracy_score(y_t, y_p)
    prec = precision_score(y_t, y_p, average='weighted', zero_division=0)
    
    print("--- Rapport GBR ---", flush=True)
    print(f"Echantillons evalues : {mask.sum()}", flush=True)
    print(f"Directional Accuracy : {acc:.2%}", flush=True)
    correct_wins = (y_t == y_p).sum()
    incorrect_loss = (y_t != y_p).sum()
    pf = correct_wins / (incorrect_loss + 1e-12) 
    print(f"Profit Factor (dir)  : {pf:.2f}", flush=True)
    print("-----------------------")
    return acc

def main():
    print("=== ÉTAPE 1 : Chargement des données ===")
    if not init_mt5():
        print("Erreur initialisation MT5.")
        return

    try:
        df = download_data()
    except Exception as e:
        print(f"Erreur download: {e}")
        shutdown_mt5()
        return

    if df.empty:
        print("Aucune donnée.")
        shutdown_mt5()
        return

    print(f"Données chargées: {len(df)} bougies.")
    
    # On reduit drastiquement pour la validation rapide
    df = df.iloc[-12000:]
    feats = build_features(df)
    target = build_target(df)
    pred_feats = get_prediction_features(feats)
    regime_feats = get_regime_features(feats)

    valid = target.notna() & pred_feats.notna().all(axis=1) & regime_feats.notna().all(axis=1)
    X = pred_feats.loc[valid]
    X_regime = regime_feats.loc[valid]
    y = target.loc[valid]
    
    split_idx = int(len(X) * 0.8)
    X_train, X_test = X.iloc[:split_idx], X.iloc[split_idx:]
    y_train, y_test = y.iloc[:split_idx], y.iloc[split_idx:]
    Xr_train, Xr_test = X_regime.iloc[:split_idx], X_regime.iloc[split_idx:]

    print(f"Dataset reduit pour validation rapide: Train {len(X_train)} | Test {len(X_test)}")

    # -- MODELE 1 : GBR Principal --
    print("\n=== ÉTAPE 3 : Validation Gradient Boosting Regressor (GBR) ===")
    gbr = ReturnPredictor()
    gbr.fit(X_train, y_train)
    
    preds_train = gbr.predict_array(X_train)
    preds_test = gbr.predict_array(X_test)
    
    print("[TRAIN]")
    evaluate_directional_accuracy(y_train.values, preds_train, "GBR Train")
    print("[TEST]")
    acc_gbr = evaluate_directional_accuracy(y_test.values, preds_test, "GBR Test")

    if acc_gbr < 0.50:
        print("ATTENTION : Le GBR performe sous 50% en test. Strategie risquee.")
    else:
        print("GBR semble OK.")

    # -- MODELE 2 : Isolation Forest --
    print("\n=== ÉTAPE 4 : Validation Isolation Forest (Régime) ===")
    iso = ConfidenceScorer()
    iso.fit(Xr_train)
    
    # On evalue seulement un echantillon pour aller vite sur le scoring individuel
    test_sample_size = min(500, len(Xr_test))
    Xr_test_samp = Xr_test.iloc[:test_sample_size]
    
    scores_test = np.array([iso.score(Xr_test_samp.iloc[[i]]) for i in range(len(Xr_test_samp))])
    # On regarde juste la distribution des scores
    print(f"Score conf moyen (Echantillon Test) : {scores_test.mean():.2f}")
    print(f"Ratio 'Normal' (>0.6)   : {(scores_test > 0.6).mean():.2%}")
    print("Isolation Forest calibree.")

    # -- MODELE 3 : Monte Carlo --
    print("\n=== ÉTAPE 5 : Validation Monte Carlo Validator ===")
    mc = MonteCarloValidator()
    print("Entraînement MC (peut prendre un peu de temps)...")
    mc.fit(X_train, y_train)
    
    # Eval sur un sous-ensemble de test pour aller vite (ex: 500 points)
    subset_size = min(500, len(X_test))
    print(f"Évaluation sur {subset_size} points de test...")
    
    mc_agreements = []
    mc_directions = []
    
    test_subset = X_test.iloc[:subset_size]
    y_subset = y_test.iloc[:subset_size]
    
    for i in range(len(test_subset)):
        row = test_subset.iloc[[i]]
        sc = mc.score(row)
        dr = mc.direction(row)
        mc_agreements.append(sc)
        mc_directions.append(dr)
        
    mc_agreements = np.array(mc_agreements)
    mc_directions = np.array(mc_directions)
    
    # Performance quand le consensus MC est fort (>0.8)
    high_conf_mask = mc_agreements > config.MC_THRESHOLD
    if high_conf_mask.sum() > 0:
        acc_mc = accuracy_score(np.sign(y_subset[high_conf_mask]), mc_directions[high_conf_mask])
        print(f"MC High Conf ({config.MC_THRESHOLD}) Accuracy : {acc_mc:.2%} sur {high_conf_mask.sum()} samples")
    else:
        print(f"Aucun sample avec confiance MC > {config.MC_THRESHOLD}")

    # -- MODELE 4 : Bootstrap --
    print("\n=== ÉTAPE 6 : Validation Bootstrap Validator ===")
    bs = BootstrapValidator()
    print("Entraînement Bootstrap...")
    bs.fit(X_train, y_train)
    
    bs_agreements = []
    bs_directions = []
    
    for i in range(len(test_subset)):
        row = test_subset.iloc[[i]]
        sc = bs.score(row)
        dr = bs.direction(row)
        bs_agreements.append(sc)
        bs_directions.append(dr)

    bs_agreements = np.array(bs_agreements)
    bs_directions = np.array(bs_directions)
    
    high_conf_bs = bs_agreements > config.BS_THRESHOLD
    if high_conf_bs.sum() > 0:
        acc_bs = accuracy_score(np.sign(y_subset[high_conf_bs]), bs_directions[high_conf_bs])
        print(f"BS High Conf ({config.BS_THRESHOLD}) Accuracy : {acc_bs:.2%} sur {high_conf_bs.sum()} samples")
    else:
        print(f"Aucun sample avec confiance BS > {config.BS_THRESHOLD}")

    print("\n=== FIN DE L'ANALYSE ===")
    shutdown_mt5()

if __name__ == "__main__":
    main()
