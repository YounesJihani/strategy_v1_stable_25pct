import sys, os, time, datetime
import MetaTrader5 as mt5
import pandas as pd
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from strategy import config
from strategy.execution.order_manager import init_mt5, shutdown_mt5, get_account_balance, get_open_positions

def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')

def get_performance_stats():
    # Load historical trades if exists
    trades_file = "historical_trades_2023_2025.csv"
    if os.path.exists(trades_file):
        try:
            trades_df = pd.read_csv(trades_file)
            n_trades = len(trades_df)
            win_rate = (trades_df['pnl'] > 0).mean() * 100 if n_trades > 0 else 0
            total_pnl = trades_df['pnl'].sum()
            return n_trades, win_rate, total_pnl
        except:
            return 0, 0, 0
    return 0, 0, 0

def monitor():
    if not init_mt5():
        print("Erreur de connexion MT5")
        return

    print("[Monitor] Démarrage de la surveillance en temps réel...")
    
    try:
        while True:
            clear_console()
            now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            # Account Info
            acc = mt5.account_info()
            balance = acc.balance if acc else 0
            equity = acc.equity if acc else 0
            margin = acc.margin if acc else 0
            free_margin = acc.margin_free if acc else 0
            
            # Open Positions
            positions = get_open_positions()
            n_open = len(positions)
            
            # Historical Stats
            n_hist, wr_hist, pnl_hist = get_performance_stats()
            
            print("="*60)
            print(f" ML STRATEGY REAL-TIME MONITOR | {now}")
            print("="*60)
            
            print(f" COMPTE:")
            print(f"  Balance:      {balance:,.2f} USD")
            print(f"  Equity:       {equity:,.2f} USD")
            print(f"  Profit Live:  {equity - balance:,.2f} USD")
            print(f"  Marge Libre:  {free_margin:,.2f} USD")
            print("-"*60)
            
            print(f" ACTIVITÉ LIVE:")
            print(f"  Positions ouvertes: {n_open}")
            if n_open > 0:
                print(f"  {'Symbole':<10} {'Type':<6} {'Volume':<8} {'Profit':<10} {'SL/TP':<15}")
                for p in positions:
                    type_str = "BUY" if p.type == mt5.POSITION_TYPE_BUY else "SELL"
                    print(f"  {p.symbol:<10} {type_str:<6} {p.volume:<8} {p.profit:<10.2f} {p.sl:.5f}/{p.tp:.5f}")
            else:
                print("  Aucune position ouverte.")
            print("-"*60)
            
            print(f" BACKTEST (OUT-OF-SAMPLE):")
            print(f"  Nombre Trades: {n_hist}")
            print(f"  Win Rate:     {wr_hist:.1f}%")
            print(f"  Total PnL:    {pnl_hist:,.2f} USD")
            print("-"*60)
            
            print(f" CONFIGURATION:")
            print(f"  Symbole:      {config.MT5_SYMBOL}")
            print(f"  Timeframe:    {config.MT5_TIMEFRAME_NAME}")
            print(f"  Risque/Trade: 1.0% (Quarter Kelly)")
            print(f"  SL ATR Mult:  {config.SL_ATR_MULT}")
            print("="*60)
            print(" Appuyez sur Ctrl+C pour quitter.")
            
            time.sleep(5)
            
    except KeyboardInterrupt:
        print("\n[Monitor] Arrêt...")
    finally:
        shutdown_mt5()

if __name__ == "__main__":
    monitor()
