"""
Bar-based backtester with slippage model and latency simulation.
"""

import numpy as np
import pandas as pd
from strategy import config
from strategy.models.feature_engineering import (
    build_features, build_target,
    get_regime_features, get_prediction_features,
)
from strategy.models.gradient_boosting import ReturnPredictor
from strategy.models.isolation_forest import ConfidenceScorer
from strategy.models.validators.walk_forward import WalkForwardValidator
from strategy.models.validators.monte_carlo import MonteCarloValidator
from strategy.models.validators.bootstrap import BootstrapValidator
from strategy.risk.position_sizer import quarter_kelly_size
from strategy.risk.stop_calculator import calculate_stops, calculate_rr15_stops
from strategy.backtest.metrics_calculator import compute_metrics, print_metrics
from strategy.models.ict_precision_entry import surgical_score_mtf


class BarBacktester:
    """
    Walk-forward backtester operating on OHLCV bars.
    Can be initialized with pre-trained models to skip training.
    """

    def __init__(
        self,
        initial_capital: float = 10_000.0,
        predictor=None,
        confidence=None,
        mc_val=None,
        bs_val=None,
        wf_score=None,
    ):
        self.initial_capital = initial_capital
        self.latency_bars = max(1, config.LATENCY_MS // 60_000)
        self.predictor = predictor
        self.confidence = confidence
        self.mc_val = mc_val
        self.bs_val = bs_val
        self.wf_score = wf_score
        
        # Kelly sizing defaults or from previous training
        self.train_win_rate = 0.52
        self.train_avg_win  = 0.001
        self.train_avg_loss = 0.001

    def run(self, df: pd.DataFrame, verbose: bool = True) -> dict:
        """
        df must have columns: open, high, low, close, tick_volume, spread, time.
        """
        n = len(df)
        if verbose:
            print(f"[Backtest] Total bars: {n:,}")

        # ── Split train / test ──
        if self.predictor:
            df_train = pd.DataFrame()
            df_test = df.copy()
            split = 0
            if verbose:
                print(f"[Backtest] Using PRE-TRAINED models. Testing on {len(df_test):,} bars.")
        else:
            train_ratio = 0.7
            split = int(n * train_ratio)
            df_train = df.iloc[:split].copy()
            df_test  = df.iloc[split:].copy()
            if verbose:
                print(f"[Backtest] Train: {len(df_train):,}  Test: {len(df_test):,}")

        # ── Build features & target on FULL data ──
        print("[Backtest] Building features ...")
        feats_all  = build_features(df)
        target_all = build_target(df)
        pred_feats = get_prediction_features(feats_all)
        regime_feats = get_regime_features(feats_all)

        if not self.predictor:
            pred_train   = pred_feats.iloc[:split]
            regime_train = regime_feats.iloc[:split]
            target_train = target_all.iloc[:split]

            self.predictor  = ReturnPredictor()
            self.confidence = ConfidenceScorer()
            self.mc_val     = MonteCarloValidator()
            self.bs_val     = BootstrapValidator()
            wf_val_obj      = WalkForwardValidator()

            if verbose:
                print("[Backtest] Training GBR ...")
            valid_mask = target_train.notna() & pred_train.notna().all(axis=1)
            self.predictor.fit(pred_train.loc[valid_mask], target_train.loc[valid_mask])

            if verbose:
                print("[Backtest] Training IsolationForest ...")
            valid_regime = regime_train.notna().all(axis=1)
            self.confidence.fit(regime_train.loc[valid_regime])

            if verbose:
                print("[Backtest] Training MC models ...")
            self.mc_val.fit(pred_train.loc[valid_mask], target_train.loc[valid_mask])

            if verbose:
                print("[Backtest] Training Bootstrap models ...")
            self.bs_val.fit(pred_train.loc[valid_mask], target_train.loc[valid_mask])

            prices_train = df_train["close"].loc[valid_mask]
            self.wf_score = wf_val_obj.score(pred_train.loc[valid_mask], target_train.loc[valid_mask], prices_train)
            
            # Compute train stats for Kelly
            train_preds = self.predictor.predict_array(pred_train.loc[valid_mask])
            train_actual = target_train.loc[valid_mask].values
            train_correct = (np.sign(train_preds) == np.sign(train_actual))
            self.train_win_rate = float(train_correct.mean())
            wins_mask = (train_correct == True)
            self.train_avg_win  = float(np.abs(train_actual[wins_mask]).mean()) if wins_mask.sum() > 0 else 0.001
            self.train_avg_loss = float(np.abs(train_actual[~wins_mask]).mean()) if (~wins_mask).sum() > 0 else 0.001

        if verbose:
            print(f"[Backtest] WF reference score: {self.wf_score:.3f}")

        # ── Pre-calculate ICT surgical scores ─────────────────────
        print("[Backtest] Computing ICT scores ...")
        ict_scores = surgical_score_mtf(df, feats_all)

        if verbose:
            print(f"[Backtest] WF reference score: {self.wf_score:.3f}")

        # ── Pre-calculate signals (Vectorized speedup) ──
        if verbose:
            print("[Backtest] Pre-calculating signals for test set ...")
            
        test_indices = df.index[split:]
        pred_test = pred_feats.loc[test_indices].fillna(0) # Masking NaNs for batch
        regime_test = regime_feats.loc[test_indices].fillna(0)
        
        # Batch Layer 1: Regime
        mc_scores = self.mc_val.score_batch(pred_test)
        mc_dirs = self.mc_val.direction_batch(pred_test)
        
        bs_scores = self.bs_val.score_batch(pred_test)
        bs_dirs = self.bs_val.direction_batch(pred_test)
        
        gbr_preds = self.predictor.predict_batch(pred_test)
        
        confidence_mask = self.confidence.batch_passes(regime_test)
        
        # Re-mask NaNs in results to be safe (so loop doesn't trade on fake 0-filled data)
        valid_mask = pred_feats.loc[test_indices].notna().all(axis=1).values
        if verbose:
            print("[Backtest] Running simulation ...")

        capital = self.initial_capital
        equity_curve = [capital]
        trades: list[dict] = []
        position = None
        trades_today = 0
        last_trade_bar = -999
        current_day = ""
        n_test = len(df_test)
        context_len = 200

        for i in range(context_len, n_test - config.FORWARD_PERIOD):
            test_idx = split + i
            bar = df.iloc[test_idx]
            price = float(bar["close"])
            high  = float(bar["high"])
            low   = float(bar["low"])

            if "time" in df.columns:
                dt_obj = pd.to_datetime(bar["time"])
                day_name = dt_obj.day_name()
                
                # Monday/Friday Filter (Item 4)
                if not config.TRADE_MONDAY and day_name == "Monday": continue
                if not config.TRADE_FRIDAY and day_name == "Friday": continue

                day = str(dt_obj.date())
                if day != current_day:
                    current_day = day
                    trades_today = 0

            # ── Phase 2.4: Trailing stop + Break-Even ──────────────────
            if position is not None:
                tp_dist = abs(position["tp"] - position["entry"]) + 1e-12

                if position["direction"] == 1:
                    progress = (high - position["entry"]) / tp_dist
                else:
                    progress = (position["entry"] - low) / tp_dist

                # Break-even at 50% TP
                if progress >= 0.5 and not position.get("breakeven_set", False):
                    position["sl"] = position["entry"]
                    position["breakeven_set"] = True

                # Trailing stop at 75% TP (0.5×ATR trail)
                if progress >= 0.75:
                    ctx_trail = df.index[test_idx]
                    atr_trail_val = feats_all["atr_raw"].loc[ctx_trail]
                    if isinstance(atr_trail_val, pd.Series):
                        atr_trail_val = atr_trail_val.iloc[0]
                    atr_trail = float(atr_trail_val)
                    if position["direction"] == 1:
                        new_sl = high - 0.5 * atr_trail
                        position["sl"] = max(position["sl"], new_sl)
                    else:
                        new_sl = low + 0.5 * atr_trail
                        position["sl"] = min(position["sl"], new_sl)

            # ── Exit logic ─────────────────────────────────────────────
            if position is not None:
                hit_sl = (position["direction"] == 1 and low <= position["sl"]) or \
                         (position["direction"] == -1 and high >= position["sl"])
                hit_tp = (position["direction"] == 1 and high >= position["tp"]) or \
                         (position["direction"] == -1 and low <= position["tp"])

                if hit_tp:
                    exit_price = position["tp"]
                    cost_bps = config.TRANSACTION_COST_BPS * 2
                    price_ret = (exit_price / position["entry"] - 1.0) * position["direction"]
                    pnl = position["volume"] * price_ret - capital * cost_bps * 1e-4
                    ret = pnl / capital
                    trades.append({"pnl": pnl, "return": ret, "direction": position["direction"], "duration": i - position["bar_idx"]})
                    capital += pnl
                    position = None
                elif hit_sl:
                    exit_price = position["sl"]
                    cost_bps = config.TRANSACTION_COST_BPS * 2
                    price_ret = (exit_price / position["entry"] - 1.0) * position["direction"]
                    pnl = position["volume"] * price_ret - capital * cost_bps * 1e-4
                    ret = pnl / capital
                    trades.append({"pnl": pnl, "return": ret, "direction": position["direction"], "duration": i - position["bar_idx"]})
                    capital += pnl
                    position = None

            equity_curve.append(capital)

            if position is not None or trades_today >= config.MAX_TRADES_PER_DAY:
                continue
            if (i - last_trade_bar) < (config.MIN_INTERVAL_SECONDS // 60):
                continue
            
            # Entry logic (using pre-calculated signals)
            # test_idx = split + i
            # Signal index in pre-calculated arrays is 'i'
            
            # Layer 1: Regime
            if not confidence_mask.iloc[i]: continue

            # Layer 2: Prediction
            prediction = gbr_preds[i]
            if not self.predictor.passes_threshold(prediction): continue
            gbr_dir = prediction["signal_direction"]

            # Layer 3: MC
            mc_score = mc_scores.iloc[i]
            if mc_score < config.MC_THRESHOLD: continue
            mc_dir = mc_dirs.iloc[i]

            # Layer 4: BS
            bs_score = bs_scores.iloc[i]
            if bs_score < config.BS_THRESHOLD: continue
            bs_dir = bs_dirs.iloc[i]

            # Layer 5: WF
            if self.wf_score < config.WF_THRESHOLD: continue

            # Consensus (Item 1 & 2)
            # --- Resolve the current dataframe index FIRST ---
            ctx_idx = df.index[test_idx]

            w = config.CONSENSUS_WEIGHTS
            consensus_raw = self.wf_score * w[0] + mc_score * w[1] + bs_score * w[2]
            
            # Layer 7: Macro Volatility Regime (Item 11 & 12)
            macro_surp_val = feats_all["macro_surprise"].loc[ctx_idx]
            if isinstance(macro_surp_val, pd.Series): macro_surp_val = macro_surp_val.iloc[0]
            
            macro_dec_val = feats_all["macro_decay"].loc[ctx_idx]
            if isinstance(macro_dec_val, pd.Series): macro_dec_val = macro_dec_val.iloc[0]
            
            from strategy.models.macro_scorer import MacroScorer
            macro_mult = MacroScorer.get_multiplier(float(macro_surp_val), float(macro_dec_val))
            
            # Apply Macro Multiplier to Consensus (Idea: News confluence)
            consensus = consensus_raw * macro_mult
            
            if consensus < config.CONSENSUS_THRESHOLD: continue

            # ── Direction : GBR SEUL (66% accuracy OOS) ─────────────────
            # MC/BS sont utilisés comme score de CONFIANCE uniquement.
            # Leur direction n'est pas fiable sur ce marché trending.
            trade_dir = gbr_dir   # LightGBM classifier décide la direction

            # ── ICT Filters — Master Spec V2 ─────────────────────────

            # ICT-1 : Kill Zone obligatoire
            def _scalar(col):
                v = feats_all[col].loc[ctx_idx]
                if isinstance(v, pd.Series): v = v.iloc[0]
                return float(v)

            in_kz = bool(_scalar("in_killzone")) if "in_killzone" in feats_all.columns else False
            if not in_kz: continue

            # ICT-2 : Biais H1 — assouplissement : h1_bias opposé interdit uniquement
            h1_bias = _scalar("h1_bias") if "h1_bias" in feats_all.columns else 0.0
            # Ne bloquer que si le biais H1 est FORTEMENT opposé (pas neutre)
            # h1_bias == 0 → pas de biais → on passe

            # ICT-3 : Score chirurgical ICT >= 0.10 (assoupli)
            surg_col = "bull_final" if trade_dir == 1 else "bear_final"
            surg_val = float(ict_scores[surg_col].iloc[test_idx]) if surg_col in ict_scores.columns else 0.0
            if surg_val < 0.10: continue

            # ICT-4 : PD Zone correcte (assoupli à 0.30)
            pd_val = _scalar("pd_zone") if "pd_zone" in feats_all.columns else 0.0
            if trade_dir == 1 and pd_val >  0.30: continue    # pas de long en forte Premium
            if trade_dir == -1 and pd_val < -0.30: continue   # pas de short en fort Discount

            # ── ATR ────────────────────────────────────────────────
            atr_val = feats_all["atr_raw"].loc[ctx_idx]
            if isinstance(atr_val, pd.Series): atr_val = atr_val.iloc[0]
            atr = float(atr_val)
            if atr < 1e-12: continue

            # ── Sizing ─────────────────────────────────────────────
            pos_size = quarter_kelly_size(
                self.train_win_rate, self.train_avg_win, self.train_avg_loss,
                capital,
            )

            # ── Stops RR=1.5 chirurgicaux ─────────────────────────
            ctx_df = df.iloc[max(0, test_idx-10):test_idx+1]
            ctx_feats = feats_all.iloc[max(0, test_idx-10):test_idx+1]
            sl, tp, pos_size, trail = calculate_rr15_stops(
                price, trade_dir, atr, capital, pos_size, ctx_df, ctx_feats
            )

            position = {"direction": trade_dir, "entry": price, "sl": sl, "tp": tp, "volume": pos_size, "bar_idx": i}
            trades_today += 1
            last_trade_bar = i

        equity_curve = np.array(equity_curve)
        
        # ── BUG 2 FIX: Correct annualization factor for M5 Forex ─────
        timeframe_name = config.MT5_TIMEFRAME_NAME
        if timeframe_name == "M1":
            bars_per_year_val = 374_400    # 60 * 24 * 5 * 52 weeks (Forex 24/5)
        elif timeframe_name == "M5":
            bars_per_year_val = 74_880     # 12 * 24 * 5 * 52 (correct M5 Forex)
        elif timeframe_name == "M15":
            bars_per_year_val = 24_960
        elif timeframe_name == "H1":
            bars_per_year_val = 6_240      # 24 * 5 * 52
        else:
            bars_per_year_val = 74_880     # fallback M5

        test_metrics = compute_metrics(
            trades, 
            equity_curve, 
            self.initial_capital, 
            n_bars=n_test,
            bars_per_year=bars_per_year_val
        )

        train_metrics = {
            "win_rate": round(float(self.train_win_rate), 4),
            "avg_win": round(float(self.train_avg_win), 6),
            "avg_loss": round(float(self.train_avg_loss), 6),
        }

        return {
            "train_metrics": train_metrics,
            "test_metrics": test_metrics,
            "trades": trades,
            "equity_curve": equity_curve,
            "wf_score": self.wf_score,
        }
