"""
Performance metrics calculator for backtesting.
"""

import numpy as np
from scipy import stats


def compute_metrics(
    trades: list[dict],
    equity_curve: np.ndarray,
    initial_capital: float,
    n_bars: int,
    bars_per_year: float | None = None,
) -> dict:
    """
    trades : list of dicts with keys 'pnl', 'return', 'direction', 'duration'
    equity_curve : array of equity values at each bar
    """
    # ── Annualisation factor (BUG 2 FIX) ──────────────────────────
    # M5 Forex 24h/5j/an :  (60/5) * 24 * 5 * 52 weeks = 74,880
    # M1 Forex             : (60/1) * 24 * 5 * 52       = 374,400
    # Using M5 as default — always pass explicitly from the caller.
    if bars_per_year is None:
        bars_per_year = 74_880   # M5 Forex — correct value
    if not trades:
        return {"error": "No trades"}

    pnls = np.array([t["pnl"] for t in trades])
    rets = np.array([t["return"] for t in trades])
    n_trades = len(trades)

    # ── Basic ──
    total_pnl = pnls.sum()
    win_mask  = pnls > 0
    n_wins    = win_mask.sum()
    win_rate  = n_wins / n_trades

    gross_profit = pnls[win_mask].sum() if n_wins > 0 else 0.0
    gross_loss   = abs(pnls[~win_mask].sum()) if (~win_mask).sum() > 0 else 1e-12
    profit_factor = gross_profit / gross_loss

    avg_win  = pnls[win_mask].mean()  if n_wins > 0 else 0.0
    avg_loss = abs(pnls[~win_mask].mean()) if (~win_mask).sum() > 0 else 1.0

    # ── Drawdown ──
    peak = np.maximum.accumulate(equity_curve)
    dd   = (peak - equity_curve) / (peak + 1e-12)
    max_dd = dd.max()

    # ── Sharpe (annualised) ──
    bar_returns = np.diff(equity_curve) / (equity_curve[:-1] + 1e-12)
    if len(bar_returns) > 1 and bar_returns.std() > 0:
        sharpe = (bar_returns.mean() / bar_returns.std()) * np.sqrt(bars_per_year)
    else:
        sharpe = 0.0

    # ── Sortino ──
    downside = bar_returns[bar_returns < 0]
    if len(downside) > 1 and downside.std() > 0:
        sortino = (bar_returns.mean() / downside.std()) * np.sqrt(bars_per_year)
    else:
        sortino = 0.0

    # ── Calmar ──
    total_years = n_bars / bars_per_year
    annual_return = total_pnl / (initial_capital * total_years + 1e-12)
    calmar = annual_return / (max_dd + 1e-12)

    # ── Recovery factor ──
    recovery_factor = total_pnl / (max_dd * initial_capital + 1e-12)

    # ── t-test ──
    if n_trades > 1:
        t_stat, p_value = stats.ttest_1samp(rets, 0)
    else:
        t_stat, p_value = 0.0, 1.0

    return {
        "n_trades":         n_trades,
        "total_pnl":        round(total_pnl, 2),
        "win_rate":         round(win_rate, 4),
        "profit_factor":    round(profit_factor, 4),
        "avg_win":          round(avg_win, 4),
        "avg_loss":         round(avg_loss, 4),
        "max_drawdown":     round(max_dd, 4),
        "sharpe":           round(sharpe, 4),
        "sortino":          round(sortino, 4),
        "calmar":           round(calmar, 4),
        "recovery_factor":  round(recovery_factor, 4),
        "t_stat":           round(float(t_stat), 4),
        "p_value":          round(float(p_value), 6),
        "annual_return":    round(annual_return, 4),
    }


def print_metrics(m: dict, title: str = "Backtest Results"):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}")
    for k, v in m.items():
        label = k.replace("_", " ").title()
        if isinstance(v, float):
            if "rate" in k or "drawdown" in k or "return" in k:
                print(f"  {label:.<30s} {v:.2%}")
            else:
                print(f"  {label:.<30s} {v:.4f}")
        else:
            print(f"  {label:.<30s} {v}")
    print(f"{'='*60}\n")
