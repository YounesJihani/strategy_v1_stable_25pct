"""
Script de test pour la CONFIG B (Trade Long sur H1).
"""
import sys, os
import MetaTrader5 as mt5
import pandas as pd

# Path setup
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from strategy import config
from strategy.train_and_backtest import download_data, statistical_report
from strategy.execution.order_manager import init_mt5, shutdown_mt5
from strategy.backtest.tick_backtester import BarBacktester
from strategy.backtest.metrics_calculator import print_metrics
from strategy.pipeline.signal_pipeline import SignalPipeline

def run_config_b():
    print("\n" + "="*60)
    print("  ÉVALUATION CONFIG B (H1 - Long Trades)")
    print("="*60)

    # 1. Écraser la configuration pour Config B
    config.MT5_TIMEFRAME_NAME = "H1"
    config.FORWARD_PERIOD = 20
    config.SL_ATR_MULT = 1.5
    config.MIN_RR_RATIO = 1.8
    
    # 2. Initialisation MT5
    if not init_mt5():
        print("Erreur MT5.")
        return

    # 3. Télécharger les données H1
    df = download_data()
    if df.empty:
        shutdown_mt5()
        return

    # 4. Entraîner et Backtester
    print("\n[Config B] Démarrage de l'entraînement et du backtest...")
    bt = BarBacktester(initial_capital=10_000.0)
    results = bt.run(df, verbose=True)

    # 5. Afficher les résultats
    print_metrics(results["test_metrics"], "RESULTATS CONFIG B (H1)")
    
    # 6. Sauvegarder séparément
    pipeline = SignalPipeline()
    # On hack un peu le fit pour qu'il utilise le DF actuel
    pipeline.fit(df.iloc[:int(len(df)*0.7)], verbose=False)
    
    # On ne sauvegarde pas par dessus les modèles A par défaut, 
    # ou on les met dans un sous-dossier si besoin.
    
    shutdown_mt5()
    print("\n[Config B] Terminé.")

if __name__ == "__main__":
    run_config_b()
